# 配置项说明

## 配置原则说明

1. UBS VirtAgent的配置能力通过文件的方式暴露。
2. UBS VirtAgent配置文件采用ini文件格式：

    - 由键（key）和值（value）构成。

    - 配置文件包含多个键值对。

    - 每个键值对用等号（**=**）进行连接；左边为键，作为配置项的名称；右边为值，作为配置项内容。

3. 配置项设计，各节点配置独立。
4. 配置后需要重启节点UBS Engine进程（UBS VirtAgent属于UBS Engine的插件，在同一进程内）。

UBS VirtAgent配置文件样例如下：

```conf
# Name of the virt_agent plugin. Fixed value: virt_agent.
ubse.plugin.name=virt_agent
# Name of the SO file on which the virt_agent module depends. Fixed value: libvirtagent.so.
ubse.plugin.pkg=libvirtagent.so
# Collection period of the VM module, in seconds. The value range is [1, 60].Any invalid value will be reset to 2.
ubse.plugin.vm.export.interval=2

# Decision configuration item
# Second escape watermark of the decision-making module. A value greater than the second escape watermark will trigger memory borrowing. The value range is [70, 95](and borrow.watermark >= high.watermark + 5).Any invalid value will be reset to 92.
borrow.watermark=92
# High and low watermark percentage configuration with a value range of [0, 100]. A high watermark triggers borrowing or migration, and a low watermark triggers returning. The value is configured to the memory subsystem and used for decision-making modules.
# [Only for virtualization scenario] High watermark percentage configuration with a value range of [65, 90](and high.watermark >= low.watermark + 5)
# [Only for virtualization scenario] Low watermark percentage configuration with a value range of [60, 80]
high.watermark=85
low.watermark=80

```

## 配置详细说明

配置项说明

| 序号  | 参数                              | 说明                                                | 取值                                                                                                                                                               |
|:----|:--------------------------------|:--------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1   | ubse.plugin.name                | VM模块插件名。                                          | 固定值为virt_agent。                                                                                                                                                  |
| 2   | ubse.plugin.pkg                 | VM模块依赖的so文件名称。                                    | 固定值为libvirtagent.so。                                                                                                                                             |
| 3   | ubse.plugin.vm.export.interval  | VM模块数据采集周期。                                       | 默认值：2<br>单位：s<br>取值范围：[1,60]<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                                                                        |
| 4   | borrow.watermark                | 决策模块第二逃生水线占比配置，高于会触发内存借用。                         | 默认值：92<br>单位：%<br>取值范围：[70,95]<br>且high.watermark <= borrow.watermark - 5<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                           |
| 5   | high.watermark                  | 决策模块第一逃生水线占比配置，高于会触发内存迁移。                   | 默认值：85<br>单位：%<br>取值范围：[65,90]<br>且low.watermark +5 <= high.watermark <= borrow.watermark - 5<br>参数配置取值范围之外或错误值都会被重置为默认值。                                       |
| 6   | low.watermark                   | 决策模块低水线占比配置，低于会触发内存归还。                    | 默认值：80<br>单位：%<br>取值范围：[60,80]<br>且low.watermark +5 <= high.watermark<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                               |
| 7   | borrow.maxMemPerBorrowSize      | 单块借用内存的借用量上限。                                     | 默认值：4096<br>单位：MB<br>取值范围：{1024,2048,3072,4096}<br>且borrow.minMemPerBorrowSize <= borrow.maxMemPerBorrowSize<br>参数配置取值范围之外或错误值都会被重置为默认值。                         |
| 8   | borrow.minMemPerBorrowSize      | 单块借用内存的借用量下限。                                     | 默认值：1024<br>单位：MB<br>取值范围：{1024,2048,3072,4096}<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                                                      |
| 9   | borrow.maxPerTotalMemBorrowSize | 单次决策最多内存借用上限。                                     | 默认值：16384<br>单位：MB<br>取值范围：[4096, 20480]<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                                                             |
| 10  | borrow.oomBorrowMemSize         | oom事件期望借用内存大小。                                    | 默认值：1024<br>单位：MB<br>取值范围：[1024,4096]<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                                                                |
| 11  | mig.ham.maxTimeout              | 单个VM确定性热迁移的任务的超时时间。                               | 默认值：60<br>单位：s<br>取值范围：[10,10800]<br>参数配置取值范围之外或错误值都会被重置为默认值。                                                                                                   |
| 12  | escape.algorithm.dir            | 自定义逃生算法so文件的绝对路径，配置中应包含so文件名称。由配置方保证加载so文件的安全可靠性。 | 默认值：/usr/lib64/libstrategy.so<br>支持用户配置为自己实现的算法so文件。                                                                                                             |
| 13  | mig.isEnableHamMigrate          | 是否支持确定性热迁移开关。                                     | 默认值：false<br>取值范围：<ul><li>false</li><li>true</li></ul>开启确定性热迁移，使用true。                                                                                                        |
| 14  | mig.migrateOneCopyMemoryBound   | UB代际下虚机热迁移决策OneCopy迁移策略的虚机内存阈值。                   | 默认值：4096<br>单位：MB<br>取值范围：[256,4096]<br>当虚机内存规格不大于mig.migrateOneCopyMemoryBound时，为OneCopy迁移；当开启确定性热迁移开关，目的节点为当前节点的邻居节点，虚拟机使用2M大页，节点间内存借用没有成环，且虚拟机内存规格大于mig.migrateOneCopyMemoryBound配置项的值时，为确定性热迁移；其他情况为MultiCopy迁移。<br>参数配置取值范围之外或错误值都会被重置为默认值。 |
| 15  | virt.pageType                   | 虚拟化场景页面类型配置。                                      | 默认值：1<br>取值范围：<br>0<br>1<br>用于设置冷内存迁出时的页面单位，标准设置为0，2M设置为1。                                                                                                       |
| 16  | virt.sceneType                  | 虚拟化场景类型应用配置。                                      | 默认值：1<br>取值范围：<br>0<br>1<br>容器场景设置为0，虚机场景设置为1。                                                                                                                   |

## 内存开销估算与 MemoryMax 配置

UBSE 以 systemd 服务（`ubse.service`）运行，进程内存上限由 unit 中的 `MemoryMax` 控制（默认 `256M`，见 `/usr/lib/systemd/system/ubse.service`）。UBS VirtAgent 作为 UBSE 的插件在同一进程内运行，其内存开销随纳管 Pod 数、活跃 borrowId 数、虚机迁出容量和超分虚机数变化；baseline 随集群节点数增长，不宜直接套用其他环境的固定值，应按式估算或在目标节点空跑实测。

**超出上限的后果**：UBSE 进程会被 cgroup 直接杀死（由 `Restart=on-failure` 重启），内存借用业务随之中断，务必预留余量。

**基线占用**：未启用插件、空跑 UBSE 时的占用随集群节点数增长，可按 `baseline(MB) ≈ 50 + 24 × (n - 1)` 估算（n 为集群节点数，cgroup 口径）；也可在目标节点停用插件后直接读取 `systemctl show ubse -p MemoryCurrent` 核对，进程口径可读 `/proc/<pid>/status`（VmRSS）或由 `/proc/<pid>/smaps_rollup` 汇总 PSS。

**总占用估算**：各场景 UBSE 进程的预计总占用为 `占用(MB) ≈ baseline(n) + 场景增量`，其中 `baseline(n)` 为上文估算（或目标节点实测）的空跑 UBSE 占用，场景增量为 3.1~3.3 各节的估算值。判断 `MemoryMax` 余量时按 `baseline(n) + 场景增量` 与 `MemoryMax` 比较（如 3 节点 `baseline ≈ 98 MB`，加上容器借用场景约 60 MB 后约 158 MB，默认 `256M` 尚有余量；8 节点 `baseline ≈ 218 MB`，加上增量后已接近默认值，应提前上调）。各节增量为进程口径估算，cgroup 口径的增量通常略高于该值，据此判断余量时应适当放宽。

**口径说明**：本章数据均只估算 UBSE 进程自身的内存增量，不包含实际借入/超分出去的内存容量本身；涉及节点总内存的估算均按物理总内存计算，未扣除操作系统、Kubernetes 与业务预留，生产规划应以节点 Allocatable 替代物理总内存。

**MemoryMax 调整**：修改 `/usr/lib/systemd/system/ubse.service` 中的 `MemoryMax`（建议用 `systemctl edit ubse` 创建 drop-in，避免升级时被覆盖），执行 `systemctl daemon-reload && systemctl restart ubse` 生效。

### 容器借用场景

容器借用场景下，稳态增量上界按下式估算：

- 最大活跃 borrowId 数：`N_borrow ≈ min(物理机内存 × 25% 借用上限 ÷ 单块最小借用 4 GB, MAX_BORROW_ID_COUNT)`
- UBSE 内存增量：`RSS 增量 ≈ B × N_borrow`

| 参数 | 含义 | 单位 |
| ---- | ---- | ---- |
| 物理机内存 | 节点物理内存总量（本例约 2860 GB） | GB |
| 25% 借用上限 | 单节点借入内存总量占物理机内存的比例上限 | % |
| 单块最小借用 4 GB | 单块借用内存规格下限，本估算按 `borrow.minMemPerBorrowSize=4096` MB 配置计算（该项默认值 1024 MB） | GB |
| MAX_BORROW_ID_COUNT | 活跃 borrowId 数的代码硬上限，取值 100（`vm_def.h`；全局借用表反序列化与 SDK 参数校验均以该值为界） | 个 |
| N_borrow | 最大活跃 borrowId 数 | 个 |
| B | 单个活跃 borrowId 的 UBSE 增量折算值（含 Pod 元数据等其余开销），约 0.6 | MB/个 |
| RSS 增量 | UBSE 进程自身 RSS 增长量（不含借入的共享内存容量） | MB |

结论：物理机内存约 2860 GB 时，容量推导值约 179 个，受 `MAX_BORROW_ID_COUNT=100` 约束后最大活跃 borrowId 数为 100 个，可借入容量上限约 `100 × 4 GB = 400 GB`，对应 UBSE 内存上涨约 60 MB（`B × N_borrow = 0.6 MB/个 × 100`）。

### 虚机碎片场景（碎片迁出）

碎片迁出场景：节点上已有一台正常虚机，剩余本地内存不足以再创建一台等大虚机；此时借用远端内存，将第一台虚机 25% 的内存迁出，腾出的本地内存用于创建第二台虚机。稳态增量与迁出容量按下式估算：

- 节点最大可迁出内存：`M_max ≈ (节点总内存 ÷ 2) × 25%`（第一台虚机迁出自身 25% 内存，本例按两台虚机等大计算）
- UBSE 内存增量：`RSS 增量 ≈ K × M_max ÷ 2 GB`

| 参数 | 含义 | 单位 |
| ---- | ---- | ---- |
| 节点总内存 | 节点物理总内存（本例约 2860 GB） | GB |
| 25% | 第一台虚机迁出自身内存的比例（本例按两台虚机等大计算） | % |
| M_max | 节点最大可迁出内存 | GB |
| K | 每借用/迁出 2 GB 的 UBSE 增量，最大情况约 4，平均情况约 2 | MB |
| RSS 增量 | UBSE 进程自身 RSS 增长量 | MB |

结论：节点总内存约 2860 GB 时，最多可迁出约 357 GB，按最大情况系数 K≈4 估算 UBSE 内存上涨约 715 MB（平均情况 K≈2 时约 360 MB）。

### 虚机超分场景

增量与虚机数量按下式估算：

- 可创建虚机数量：`N_max ≈ min(节点总内存 ÷ 单虚机规格, MAX_VM_NUM)`
- UBSE 内存增量：`RSS 增量 ≈ C × N_vm`

| 参数 | 含义 | 单位 |
| ---- | ---- | ---- |
| 节点总内存 | 节点物理总内存（本例约 2860 GB） | GB |
| 单虚机规格 | 虚机内存规格（本例 8G） | GB |
| MAX_VM_NUM | 虚机数量的代码规划上限，取值 300（`vm_def.h`） | 个 |
| N_max | 可创建虚机数量上限 | 个 |
| N_vm | 超分虚机数量 | 个 |
| C | 单虚机 UBSE 增量，平均情况约 5，最大情况约 10 | MB |
| RSS 增量 | UBSE 进程自身 RSS 增长量 | MB |

结论：节点总内存约 2860 GB 时，容量推导值约 357 个，受 `MAX_VM_NUM=300` 约束后最大虚机数为 300 个，按最大情况系数 10 MB/个估算，UBSE 内存上涨约 3000 MB（≈ 3 GB）。

### MemoryMax 配置建议

按上述估算式，各场景 UBSE 进程增量上界汇总如下（规划时按实际部署的场景与规模取值）：

| 场景 | 典型负载 | UBSE 增量上界 | 按 `baseline(n) + 增量` 与默认 MemoryMax=256M 的关系 |
| ---- | -------- | ------------- | ------------------------------------------------------ |
| 容器借用 | 100 个活跃 borrowId（受 MAX_BORROW_ID_COUNT 约束，可借入容量上限约 400 GB） | ≈ 60 MB | 3 节点约 158 MB，默认值尚有余量；节点数多时需按式核算 |
| 虚机碎片迁出 | 迁出约 357 GB | ≈ 715 MB（最大 K≈4；平均 K≈2 时约 360 MB） | 已超过默认值，需要上调 |
| 虚机超分 | 300 个 8G 虚机（受 MAX_VM_NUM 约束） | ≈ 3 GB | 已超过默认值，需要上调 |

- 表内增量为各场景上界，判断余量应按 `baseline(n) + 增量` 与 `MemoryMax` 比较（`baseline(n)` 见本章开头的「基线占用」，如 3 节点约 98 MB、8 节点约 218 MB）；调整方法与超限后果见本章开头的「MemoryMax 调整」。
