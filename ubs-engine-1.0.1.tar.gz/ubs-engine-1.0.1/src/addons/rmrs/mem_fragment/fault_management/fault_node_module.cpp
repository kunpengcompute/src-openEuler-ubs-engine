/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 
 * UBS RMRS is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
*/

#include "fault_node_module.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <set>
#include <thread>
#include <unordered_map>
#include <unordered_set>

#include "ubse_com.h"
#include "ubse_error.h"
#include "ubse_mem_controller.h"
#include "ubse_pointer_process.h"
#include "OsHelper/OsHelper.h"
#include "export_type.h"
#include "exporter.h"
#include "fault_memid_helper.h"
#include "mem_borrow_executor.h"
#include "mem_manager.h"
#include "mempooling_message.h"
#include "mp_configuration.h"
#include "mp_json_util.h"
#include "over_commit_fault_memid_module.h"
#include "over_commit_pid_fault_error_util.h"
#include "rmrs_serialize.h"

namespace mempooling {
using namespace mempooling::smap;
using namespace ubse::log;
using namespace ubse::com;
using namespace ubse::mem::controller;
using namespace mempooling::message;
using namespace rmrs::serialize;

constexpr int SMAP_OK = 0;
constexpr int SMAP_ERROR = 1;
constexpr auto DELETERE_KIND = "MEM";
constexpr uint64_t KB_1024 = 1024ULL;
constexpr uint64_t BLOCK_SIZE_KB = 128 * KB_1024;
constexpr size_t RPC_RESP_LENGTH = 2;

#define LOG_DEBUG UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
#define LOG_ERROR UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
#define LOG_INFO UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
#define LOG_WARN UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)

uint64_t FaultNodeModule::sBlockSizeKb = BLOCK_SIZE_KB; // 静态成员初始化

void FaultNodeModule::SetBlockSizeKB(const std::string& nodeId)
{
    const auto allNodeInfo = UbseNodeController::GetInstance().GetAllNodes();
    auto it = allNodeInfo.find(nodeId);
    if (it == allNodeInfo.end()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowStrategy] GetAllNodes failed, nodeId=" << nodeId << ".";
        sBlockSizeKb = BLOCK_SIZE_KB;
        return;
    }

    // blockSize 单位是 MB，转换为 KB
    sBlockSizeKb = static_cast<uint64_t>(it->second.blockSize) * KB_1024;
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[SetBlockSizeKB] Set BlockSizeKB=" << sBlockSizeKb << ".";
}

uint64_t FaultNodeModule::GetBlockSizeKB()
{
    if (sBlockSizeKb == 0) {
        // 未被初始化时，使用一个安全默认值（128MB）
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE) << "[GetBlockSizeKB] BlockSize not set, using default 128MB.";
        return BLOCK_SIZE_KB;
    }
    return sBlockSizeKb;
}

MpResult FaultNodeModule::DetermineNodeTypeOverCommit(const std::string nodeId, NodeType& nodeType)
{
    MpResult ret = MEM_POOLING_OK;
    std::vector<UbseNumaMemoryDebtInfo> debtInfos;
    UbseResult retErrorCode = UbseGetNumaMemDebtInfoWithNode(nodeId, debtInfos);
    if (retErrorCode != UBSE_OK && retErrorCode != UBSE_MEMCONTROLLER_ERROR_PAR_SUCCESS) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][OverCommit] Call UbseGetNumaMemDebtInfoWithNode failed.";
        nodeType = NodeType::ABNORMAL;
        return MEM_POOLING_ERROR;
    }
    if (debtInfos.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][OverCommit] Node:" << nodeId << " has no debt infos, ret=" << ret << ".";
        nodeType = NodeType::NO_RECORD;
        return ret;
    }
    // nodeId与记录中借出节点相同
    if (debtInfos[0].lentNodeId == nodeId) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][OverCommit] Node:" << nodeId << " NodeType: BORROW_OUT.";
        nodeType = NodeType::BORROW_OUT;
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][OverCommit] Node:" << nodeId << " NodeType: BORROW_IN.";
        nodeType = NodeType::BORROW_IN;
    }
    return ret;
}

MpResult FaultNodeModule::DetermineNodeTypeFragment(const std::string nodeId, NodeType& nodeType)
{
    MpResult ret = MEM_POOLING_OK;
    std::vector<BorrowRecord> fragMentFaultBorrowRecords;
    MpResult retErrorCode =
        BorrowRecordHelper::Instance().GetFragmentFaultBorrowRecords(nodeId, fragMentFaultBorrowRecords);
    if (retErrorCode != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] GetFragmentFaultBorrowRecords failed.";
        nodeType = NodeType::ABNORMAL;
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    if (fragMentFaultBorrowRecords.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] Node:" << nodeId << " has no debt infos, ret=" << ret << ".";
        nodeType = NodeType::NO_RECORD;
        return ret;
    }
    // nodeId与记录中借出节点相同
    if (fragMentFaultBorrowRecords[0].lentNode == nodeId) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] Node:" << nodeId << " NodeType: BORROW_OUT.";
        nodeType = NodeType::BORROW_OUT;
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] Node:" << nodeId << " NodeType: BORROW_IN.";
        nodeType = NodeType::BORROW_IN;
    }
    return ret;
}

MpResult FaultNodeModule::DetermineNodeType(const std::string nodeId, NodeType& nodeType)
{
    std::vector<BorrowRecord> borrowRecords;
    auto ret = BorrowRecordHelper::Instance().CollectBorrowRecords(nodeId, borrowRecords);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] Call QueryMemRecoreds failed.";
        nodeType = NodeType::ABNORMAL;
        return ret;
    }
    if (borrowRecords.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] Node:" << nodeId << "has no borrow records.";
        nodeType = NodeType::NO_RECORD;
        return MEM_POOLING_OK;
    }
    // nodeId与记录中借出节点相同
    if (borrowRecords[0].lentNode == nodeId) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] Node:" << nodeId << " NodeType: BORROW_OUT.";
        nodeType = NodeType::BORROW_OUT;
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] Node:" << nodeId << " NodeType: BORROW_IN.";
        nodeType = NodeType::BORROW_IN;
    }
    return ret;
}

bool FaultNodeModule::QueryNumaAllPid(uint16_t numaId, std::vector<pid_t>& pidList)
{
    std::vector<mempooling::exportV2::VmDomainInfo> vmDomainInfos;
    uint32_t queryVmRes = mempooling::exportV2::Exporter::GetVmInfoImmediately(vmDomainInfos);
    if (queryVmRes != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] CurNode query vm error.";
        return false;
    }
    if (vmDomainInfos.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] CurNode vm empty.";
        return false;
    }
    for (const auto& vmDomainInfo : vmDomainInfos) {
        // 查找远端 NUMA
        for (const auto& kv : vmDomainInfo.numaInfo) {
            const mempooling::exportV2::VmDomainNumaInfo& numa = kv.second;
            if (!numa.isLocal && numa.numaId == numaId) {
                pidList.push_back(vmDomainInfo.metaData.pid);
                break; // 一个 VM 最多只有一个远端 NUMA
            }
        }
    }
    if (pidList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] PID empty.";
        return false;
    }
    return true;
}

bool FaultNodeModule::AllocateHugePage(uint16_t numaId, uint64_t hugePageMemSize)
{
    std::vector<uint64_t> numaIdList{static_cast<uint64_t>(numaId)};
    std::vector<uint64_t> borrowSizeList{hugePageMemSize};
    if (MpSmapHelper::GetInstance().AllocateHugePages(numaIdList, borrowSizeList)) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] No vm AllocateHugePages failed.";
        return false;
    }
    return true;
}

bool FaultNodeModule::SwitchMigrateForNumaVm(std::vector<pid_t> pidList, int enable)
{
    // 预留字段暂无意义
    int flags = 0;
    // 关闭pid级别冷热迁移
    int res = MpSmapHelper::SmapEnableProcessMigrateHelper(pidList.data(), pidList.size(), enable, flags);
    if (res != SMAP_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] SmapEnableProcessMigrateHelper failed.";
        return false;
    }
    return true;
}

bool FaultNodeModule::GenerateMigrateNumaMsgList(NumaReplaceReturnMsg rpcMsg, std::vector<MigrateNumaMsg>& msgList)
{
    for (MigrateBorrowRecord record : rpcMsg.migrateBorrowRecordList) {
        if (record.memIdList.size() > MAX_NR_MIGNUMA) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] The size of record is invalid.";
            return false;
        }
        MigrateNumaMsg msg;
        MigrateNumaPayload payloadList;
        for (size_t i = 0; i < record.memIdList.size(); i++) {
            msg.memids[i] = record.memIdList[i];
        }
        msg.srcNid = rpcMsg.srcNid;
        msg.destNid = rpcMsg.destNid;
        msg.count = static_cast<int>(record.memIdList.size());
        msgList.push_back(msg);
    }
    return true;
}

bool FaultNodeModule::ExecMigrateRemoteNumaToNuma(NumaReplaceReturnMsg rpcMsg, std::vector<MigrateNumaMsg> msgList)
{
    if (msgList.size() == 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] InPutParam empty.";
        return false;
    }
    // 单远端numa
    std::vector<uint64_t> numaIdList{static_cast<uint64_t>(msgList[0].destNid)};
    // 查看需要分配大页数量
    if (rpcMsg.destNid != msgList[0].destNid) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] Remote NUMAID ERROR.";
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] Param destNid=" << rpcMsg.destNid
            << ", msgList[0].destNid=" << msgList[0].destNid << ".";
        return false;
    }

    // 计算需要分配大页的内存大小，单位b
    uint64_t hugePageMemSize = 0;
    for (size_t i = 0; i < rpcMsg.BorrowExecuteParamVec.size(); i++) {
        hugePageMemSize += rpcMsg.BorrowExecuteParamVec[i].memSize;
    }
    hugePageMemSize = hugePageMemSize * KB_1024;
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager] [FaultLentNode] Param hugePageMemSize=" << hugePageMemSize << "B, srcNid=" << rpcMsg.srcNid
        << ", destNid=" << rpcMsg.destNid << ".";

    // 全量分大页
    std::vector<uint64_t> borrowSizeList{hugePageMemSize};
    MpResult res = MpSmapHelper::GetInstance().AllocateHugePages(numaIdList, borrowSizeList);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] AllocateHugePages failed.";
        return false;
    }
    for (MigrateNumaMsg msg : msgList) {
        res = MpSmapHelper::SmapMigrateRemoteNuma(msg);
        if (res != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] SmapMigrateRemoteNuma failed, srcNumaId " << msg.srcNid
                << ", destNumaId " << msg.destNid;
            return false;
        }
    }
    return true;
}

MpResult FaultNodeModule::GetBorrowNodeInfo(std::string nodeId, std::vector<BorrowRecord>& borrowRecords)
{
    UbseResult res = BorrowRecordHelper::Instance().GetFragmentFaultBorrowRecords(nodeId, borrowRecords);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] GetFragmentFaultBorrowRecords failed, nodeId=" << nodeId;
        return MEM_POOLING_ERROR;
    }
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::GetBorrowAbleNodeIdList(std::string curDealNodeId,
                                                  std::vector<std::string>& borrowAbleNodeIdList)
{
    // 目前架构能查到的所有的节点都可以借用 查询所有节点
    std::vector<std::string> allNodeIdList = MpConfiguration::GetInstance().GetNodeIds();
    if (allNodeIdList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] All nodeId list is empty, curDealNodeId=" << curDealNodeId << ".";
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    // 去除掉故障节点、已经是借入节点的节点(自己也是)
    for (std::string nodeId : allNodeIdList) {
        NodeType nodeType = NodeType::ABNORMAL;
        FaultNodeModule::Instance().DetermineNodeTypeFragment(nodeId, nodeType);
        ubse::nodeController::UbseNodeInfo info = UbseNodeController::GetInstance().GetNodeById(nodeId);
        if (info.clusterState == ubse::nodeController::UbseNodeClusterState::UBSE_NODE_WORKING &&
            nodeId != curDealNodeId && (nodeType == NodeType::BORROW_OUT || nodeType == NodeType::NO_RECORD)) {
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Borrow able nodeId " << nodeId << ".";
            borrowAbleNodeIdList.push_back(nodeId);
        }
    }
    if (borrowAbleNodeIdList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] No borrowable nodeId " << curDealNodeId << ".";
        return MEM_POOLING_FAULT_LACK_REMOTE_MEM_ERROR;
    }
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::GetBorrowAbleNodeInfoSortByMemSize(
    std::vector<std::string> borrowAbleNodeIdList, std::vector<NodeMemoryInfoWithReservedMem>& ableNodeMemInfoList)
{
    // 获取可借用节点的 节点-numa 内存余量
    MpResult res = BorrowRecordHelper::Instance().CollectBorrowableInfoList(borrowAbleNodeIdList, ableNodeMemInfoList);
    if (res != MEM_POOLING_OK || ableNodeMemInfoList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] CollectBorrowableInfoList failed, err=" << res << ".";
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    // 节点可借内存从大到小排序
    std::sort(ableNodeMemInfoList.begin(), ableNodeMemInfoList.end(),
              [](NodeMemoryInfoWithReservedMem l1, NodeMemoryInfoWithReservedMem l2) {
                  return l1.canBorrowMem > l2.canBorrowMem;
              });
    // 节点内numa可借内存从大到小排序
    for (NodeMemoryInfoWithReservedMem& record : ableNodeMemInfoList) {
        // 也按照借用大小从大到小排序
        std::sort(record.numaMemInfo.begin(), record.numaMemInfo.end(),
                  [](RackNumaMemInfo l1, RackNumaMemInfo l2) { return l1.canBorrowMem > l2.canBorrowMem; });
    }
    return MEM_POOLING_OK;
}

void FaultNodeModule::MergeBorrowRecords(std::vector<BorrowRecord> borrowRecordList,
                                         std::vector<NodeBorrowRecord>& nodeBorrowRecordList)
{
#ifdef UB_ENVIRONMENT
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] UB MergeBorrowRecords";
    std::unordered_map<std::string, NodeBorrowRecord> borrowRecordGroupByNodeIdMap;
    for (BorrowRecord record : borrowRecordList) {
        std::string key = record.borrowNode + "_" + record.lentNode + "_" + std::to_string(record.lentSocketId);
        uint16_t borrowSocketId{0};
        MemManager::Instance().GetSocketId(record.borrowNode, record.borrowLocalNuma, borrowSocketId);
        OnceBorrowRecord onceBorrowRecord{record.name,
                                          record.size,
                                          record.borrowMemId,
                                          static_cast<uint16_t>(record.borrowRemoteNuma),
                                          static_cast<uint16_t>(record.borrowLocalNuma),
                                          record.uid,
                                          record.username};
        if (borrowRecordGroupByNodeIdMap.find(key) != borrowRecordGroupByNodeIdMap.end()) {
            NodeBorrowRecord borrowRecord = borrowRecordGroupByNodeIdMap[key];
            borrowRecord.borrowMemSize += record.size;
            borrowRecord.onceBorrowRecordList.push_back(onceBorrowRecord);
            borrowRecordGroupByNodeIdMap[key] = borrowRecord;
        } else {
            NodeBorrowRecord nodeBorrowRecord{record.borrowNode, borrowSocketId, record.size, {onceBorrowRecord}};
            borrowRecordGroupByNodeIdMap[key] = nodeBorrowRecord;
        }
    }
    for (auto borrowRecordEntry : borrowRecordGroupByNodeIdMap) {
        nodeBorrowRecordList.push_back(borrowRecordEntry.second);
    }
#else
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] HCCS MergeBorrowRecords";
    std::unordered_map<std::string, std::vector<BorrowRecord>> borrowRecordGroupByNodeIdMap;
    for (BorrowRecord record : borrowRecordList) {
        borrowRecordGroupByNodeIdMap[record.borrowNode].push_back(record);
    }
    for (auto borrowRecordEntry : borrowRecordGroupByNodeIdMap) {
        NodeBorrowRecord tmpNodeBorrowRecord;
        tmpNodeBorrowRecord.nodeId = borrowRecordEntry.first;
        for (BorrowRecord recordItem : borrowRecordEntry.second) {
            tmpNodeBorrowRecord.borrowMemSize += recordItem.size;
            OnceBorrowRecord onceBorrowRecord{recordItem.name, recordItem.size, recordItem.borrowMemId,
                                              static_cast<uint16_t>(recordItem.borrowRemoteNuma),
                                              static_cast<uint16_t>(recordItem.borrowLocalNuma)};
            tmpNodeBorrowRecord.onceBorrowRecordList.push_back(onceBorrowRecord);
        }
        nodeBorrowRecordList.push_back(tmpNodeBorrowRecord);
    }
#endif
    // socket级别记录按借用大小从大到小排序
    std::sort(nodeBorrowRecordList.begin(), nodeBorrowRecordList.end(),
              [](NodeBorrowRecord r1, NodeBorrowRecord r2) { return r1.borrowMemSize > r2.borrowMemSize; });
    // 每一个节点内部的借用记录
    for (NodeBorrowRecord& record : nodeBorrowRecordList) {
        // socket内也按照借用大小从大到小排序
        std::sort(record.onceBorrowRecordList.begin(), record.onceBorrowRecordList.end(),
                  [](OnceBorrowRecord l1, OnceBorrowRecord l2) { return l1.borrowSize > l2.borrowSize; });
    }
}

bool FaultNodeModule::MayBorrowFromNuma(NodeBorrowRecord nodeBorrowRecord,
                                        NodeMemoryInfoWithReservedMem& originNodeMemInfoItem,
                                        NodeMemoryInfoWithReservedMem nodeMemInfoItem,
                                        std::vector<BorrowExecuteParam>& borrowExecuteParamCollectList)
{
    std::vector<BorrowExecuteParam> tmpList;
    std::map<uint16_t, uint64_t> sizeRecordMap;
    for (OnceBorrowRecord record : nodeBorrowRecord.onceBorrowRecordList) {
        RackNumaMemInfo item = nodeMemInfoItem.numaMemInfo[0];
        BorrowExecuteParam param;
        if (record.borrowSize > item.canBorrowMem) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Numa mem no enough "
                << " needBorrowSize " << record.borrowSize << " numaCanBorrowSize " << item.canBorrowMem << " nodeId "
                << nodeMemInfoItem.nodeId << " numaId " << item.numaId << ".";
            return false;
        }
        param.borrowNodeId = nodeBorrowRecord.nodeId;
        param.borrowNumaId = record.localNumaId;
        param.oldNumaId = record.numaId;
        param.lentNodeId = nodeMemInfoItem.nodeId;
        param.lentNumaId = item.numaId;
        param.memSize = record.borrowSize;
        param.memIdList = record.memIdList;
        param.oldBorrowId = record.borrowId;
        param.uid = record.uid;
        param.username = record.username;
        tmpList.push_back(param);
        nodeMemInfoItem.canBorrowMem -= record.borrowSize;
        nodeMemInfoItem.numaMemInfo[0].canBorrowMem -= record.borrowSize;
        std::sort(nodeMemInfoItem.numaMemInfo.begin(), nodeMemInfoItem.numaMemInfo.end(),
                  [](RackNumaMemInfo l1, RackNumaMemInfo l2) { return l1.canBorrowMem > l2.canBorrowMem; });
    }
    originNodeMemInfoItem = nodeMemInfoItem;
    (void)borrowExecuteParamCollectList.insert(borrowExecuteParamCollectList.end(), tmpList.begin(), tmpList.end());
    for (BorrowExecuteParam borrowExecuteParamItem : borrowExecuteParamCollectList) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] [FaultLentNode] Borrow execute param collect " << borrowExecuteParamItem.ToString()
            << ".";
    }
    return true;
}

MpResult FaultNodeModule::NodeMayBorrowFromOtherNode(NodeBorrowRecord nodeBorrowRecord,
                                                     std::vector<NodeMemoryInfoWithReservedMem>& ableNodeMemInfoList,
                                                     std::vector<BorrowExecuteParam>& borrowExecuteParamCollectList)
{
    std::unordered_set<std::string> couldBorrowNodeSet;
    auto ret = MpParseGroupProviderConf::Instance().GetBorrowableList(nodeBorrowRecord.nodeId, couldBorrowNodeSet);
    if (ret != MEM_POOLING_OK) {
        LOG_ERROR << "[FaultManager] [FaultLentNode] GetBorrowableList failed.";
        return MEM_POOLING_ERROR;
    }
    std::vector<std::string> antiNodeMemVec;
    AntiNode::Instance().Query(nodeBorrowRecord.nodeId, antiNodeMemVec);
    for (const auto& node : antiNodeMemVec) {
        couldBorrowNodeSet.erase(node);
    }
    bool mustSamePlane = MpConfiguration::GetInstance().GetMustSamePlane();
    std::unordered_map<std::string, BorrowItem> borrowCacheAll;
    MemReturnManager::Instance().QueryAll(borrowCacheAll);
    for (auto& kv : borrowCacheAll) {
        if (kv.second.srcNid == nodeBorrowRecord.nodeId &&
            (!mustSamePlane ||
             MemManager::Instance().JudgeSampPlane(nodeBorrowRecord.nodeId, nodeBorrowRecord.borrowSocketId,
                                                   kv.second.dstNid, kv.second.dstSocketId))) {
            LOG_DEBUG << "[FaultManager] Node=" << kv.second.dstNid << " has return timeout records, erase it.";
            couldBorrowNodeSet.erase(kv.second.dstNid);
        }
    }
    for (NodeMemoryInfoWithReservedMem& nodeMemInfoItem : ableNodeMemInfoList) {
        if (mustSamePlane &&
            !MemManager::Instance().JudgeSampPlane(nodeMemInfoItem.nodeId, nodeMemInfoItem.socketId,
                                                   nodeBorrowRecord.nodeId, nodeBorrowRecord.borrowSocketId)) {
            continue;
        }
        if (couldBorrowNodeSet.find(nodeMemInfoItem.nodeId) == couldBorrowNodeSet.end()) {
            continue;
        }
        if (nodeMemInfoItem.canBorrowMem < nodeBorrowRecord.borrowMemSize) {
            // 可借用节点中最大的可借用内存都不够借用 直接给到memId级别处理
            LOG_ERROR << "[FaultManager] [FaultLentNode] No node can borrow"
                      << "nodeId " << nodeBorrowRecord.nodeId << " needBorrowMemSize " << nodeBorrowRecord.borrowMemSize
                      << " canBorrowMemSize " << nodeMemInfoItem.canBorrowMem << ".";
            return MEM_POOLING_ERROR;
        }
        if (MayBorrowFromNuma(nodeBorrowRecord, nodeMemInfoItem, nodeMemInfoItem, borrowExecuteParamCollectList)) {
            return MEM_POOLING_OK;
        }
        LOG_WARN << "[FaultManager] [FaultLentNode] No MayBorrowFromNuma"
                 << "nodeId " << nodeBorrowRecord.nodeId << " needBorrowMemSize " << nodeBorrowRecord.borrowMemSize;
    }
    return MEM_POOLING_ERROR;
}

MpResult FaultNodeModule::MayBorrowFromOtherNode(std::string curDealNodeId, std::vector<BorrowRecord> borrowRecords,
                                                 std::vector<BorrowExecuteParam>& borrowExecuteParamCollectList,
                                                 std::vector<ForwardMemIdParam>& forwardMemIdParamList)
{
    std::vector<std::string> borrowAbleNodeIdList;
    MpResult res = GetBorrowAbleNodeIdList(curDealNodeId, borrowAbleNodeIdList);
    if (res != MEM_POOLING_OK) {
        return MEM_POOLING_ERROR;
    }
    std::vector<NodeMemoryInfoWithReservedMem> ableNodeMemInfoList;
    res = GetBorrowAbleNodeInfoSortByMemSize(borrowAbleNodeIdList, ableNodeMemInfoList);
    if (res != MEM_POOLING_OK) {
        return MEM_POOLING_ERROR;
    }
    // nodeId维度合并借入故障节点的记录
    std::vector<NodeBorrowRecord> nodeBorrowRecordList;
    MergeBorrowRecords(borrowRecords, nodeBorrowRecordList);
    std::vector<NodeBorrowRecord> failedNodeBorrowRecordList;
    for (NodeBorrowRecord nodeBorrowRecordItem : nodeBorrowRecordList) {
        // 判断单个借入节点能否从所有可借用节点借用到足够的内存 可以借用到就直接更新可借用节点的可借用内存信息
        std::sort(
            ableNodeMemInfoList.begin(), ableNodeMemInfoList.end(),
            [&nodeBorrowRecordItem](const NodeMemoryInfoWithReservedMem& l1, const NodeMemoryInfoWithReservedMem& l2) {
                bool l1enough = l1.canBorrowMem >= nodeBorrowRecordItem.borrowMemSize;
                bool l2enough = l2.canBorrowMem >= nodeBorrowRecordItem.borrowMemSize;
                if (l1enough != l2enough) {
                    return l1enough;
                }
                bool l1SamePlane = MemManager::Instance().JudgeSampPlane(
                    nodeBorrowRecordItem.nodeId, nodeBorrowRecordItem.borrowSocketId, l1.nodeId, l1.socketId);
                bool l2SamePlane = MemManager::Instance().JudgeSampPlane(
                    nodeBorrowRecordItem.nodeId, nodeBorrowRecordItem.borrowSocketId, l2.nodeId, l2.socketId);
                if (l1SamePlane != l2SamePlane) {
                    return l1SamePlane; // true 会排前面
                }
                return l1.canBorrowMem > l2.canBorrowMem;
            });

        for (auto& nodeMemInfo : ableNodeMemInfoList) {
            LOG_DEBUG << "NodeId = " << nodeMemInfo.nodeId << " , socketId = " << nodeMemInfo.socketId
                      << " , canBorrowMem = " << nodeMemInfo.canBorrowMem;
            for (auto& numaInfo : nodeMemInfo.numaMemInfo) {
                LOG_DEBUG << "numaInfo = " << numaInfo.ToString();
            }
        }
        // 有不能借用的全部降为memId级故障处理
        res = NodeMayBorrowFromOtherNode(nodeBorrowRecordItem, ableNodeMemInfoList, borrowExecuteParamCollectList);
        if (res != MEM_POOLING_OK) {
            failedNodeBorrowRecordList.push_back(nodeBorrowRecordItem);
            continue;
        }
    }
    for (NodeBorrowRecord nodeBorrowRecordItem : failedNodeBorrowRecordList) {
        std::string importNodeId = nodeBorrowRecordItem.nodeId;
        for (OnceBorrowRecord onceBorrowRecord : nodeBorrowRecordItem.onceBorrowRecordList) {
            ForwardMemIdParam param{importNodeId, onceBorrowRecord.memIdList, onceBorrowRecord.uid,
                                    onceBorrowRecord.username};
            forwardMemIdParamList.push_back(param);
        }
    }
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::FillBorrowExecuteParam(std::vector<BorrowExecuteParam>& borrowExecuteParamCollectList)
{
    if (borrowExecuteParamCollectList.empty()) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] [FaultLentNode] Execute list empty.";
        return MEM_POOLING_OK;
    }
    for (BorrowExecuteParam& param : borrowExecuteParamCollectList) {
        uint16_t borrowSocketId;
        uint16_t lentSocketId;
        MpResult ret = MemManager::Instance().GetSocketId(param.borrowNodeId, param.borrowNumaId, borrowSocketId);
        ret |= MemManager::Instance().GetSocketId(param.lentNodeId, param.lentNumaId, lentSocketId);
        if (ret) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Can't find numaId form socket.";
            return MEM_POOLING_ERROR;
        }
        param.borrowSocketId = static_cast<uint16_t>(borrowSocketId);
        param.lentSocketId = static_cast<uint16_t>(lentSocketId);
    }
    return MEM_POOLING_OK;
}

bool FaultNodeModule::DealBorrowResult(std::vector<BorrowExecuteParam>& borrowExecuteParamList,
                                       std::vector<BorrowExecuteParam>& successExecuteParamCollectList,
                                       std::vector<MemBorrowExecuteResult> resultList)
{
    for (size_t i = 0; i < borrowExecuteParamList.size(); i++) {
        borrowExecuteParamList[i].newNumaId = resultList[i].presentNumaId[0];
        borrowExecuteParamList[i].newBorrowId = resultList[i].borrowIds[0];
        successExecuteParamCollectList.push_back(borrowExecuteParamList[i]);
    }
    return true;
}

void FaultNodeModule::DoExecuteBorrow(std::vector<BorrowExecuteParam>& successExecuteParamCollectList,
                                      std::pair<std::string, std::vector<BorrowExecuteParam>> nodeBorrowExecuteParam,
                                      std::vector<ForwardMemIdParam>& forwardMemIdParamList)
{
    std::vector<MemBorrowExecuteResult> resultList;
    for (BorrowExecuteParam borrowExecuteParam : nodeBorrowExecuteParam.second) {
        SrcMemoryBorrowParam srcParam{
            borrowExecuteParam.borrowNodeId, static_cast<int16_t>(borrowExecuteParam.borrowSocketId),
            static_cast<int16_t>(borrowExecuteParam.borrowNumaId), borrowExecuteParam.uid, borrowExecuteParam.username};
        MemBorrowExecuteResult borrowExecuteResult;
        std::vector<DestMemoryBorrowParam> destParamList;
        uint16_t destNumaNum = 1; // 当前限制为1
        std::vector<int> destNumaIdList{borrowExecuteParam.lentNumaId};
        std::vector<uint64_t> memSizeList{borrowExecuteParam.memSize};
        DestMemoryBorrowParam destMemoryBorrowParam{borrowExecuteParam.lentNodeId, borrowExecuteParam.lentSocketId,
                                                    destNumaNum, destNumaIdList, memSizeList};
        destParamList.push_back(destMemoryBorrowParam);
        MpResult res = MempoolBorrowModule::Instance().MemBorrowExecute(srcParam, destParamList, borrowExecuteResult);
        if (res) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Borrow mem error srcNode " << borrowExecuteParam.borrowNodeId
                << " destNode " << borrowExecuteParam.lentNodeId << " size " << borrowExecuteParam.memSize << ".";
            break;
        }
        resultList.push_back(borrowExecuteResult);
    }
    // 执行结果和执行集的数量不等说明有失败的
    if (resultList.size() == nodeBorrowExecuteParam.second.size()) {
        DealBorrowResult(nodeBorrowExecuteParam.second, successExecuteParamCollectList, resultList);
    } else {
        for (BorrowExecuteParam borrowExecuteParam : nodeBorrowExecuteParam.second) {
            ForwardMemIdParam param{borrowExecuteParam.borrowNodeId, borrowExecuteParam.memIdList,
                                    borrowExecuteParam.uid, borrowExecuteParam.username};
            forwardMemIdParamList.push_back(param);
        }
    }
}

void FaultNodeModule::ExecuteBorrow(std::vector<BorrowExecuteParam>& borrowExecuteParamCollectList,
                                    std::vector<BorrowExecuteParam>& successExecuteParamCollectList,
                                    std::vector<ForwardMemIdParam>& forwardMemIdParamList)
{
    if (borrowExecuteParamCollectList.empty()) {
        return;
    }
    // 按照接入节点分组 如果有一个执行失败就转为memId级故障处理
    std::unordered_map<std::string, std::vector<BorrowExecuteParam>> nodeBorrowExecuteParamMap;
    for (BorrowExecuteParam param : borrowExecuteParamCollectList) {
        nodeBorrowExecuteParamMap[param.borrowNodeId].push_back(param);
    }
    for (auto& nodeBorrowExecuteParam : nodeBorrowExecuteParamMap) {
        DoExecuteBorrow(successExecuteParamCollectList, nodeBorrowExecuteParam, forwardMemIdParamList);
    }
}

MpResult FaultNodeModule::ForwardMemIdFaultDeal(std::vector<ForwardMemIdParam> forwardMemIdParamList,
                                                bool forceDeleteMem)
{
    MpResult res = MEM_POOLING_OK;
    for (ForwardMemIdParam param : forwardMemIdParamList) {
        if (param.memIdList.empty()) {
            res = MEM_POOLING_ERROR;
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Forward memId deal but memId empty, nodeId " << param.importNodeId
                << ".";
            continue;
        }
        if (FaultMemIdHelper::Instance().FaultMemIdManageHelper(param.importNodeId, param.memIdList[0], forceDeleteMem,
                                                                true)) {
            res = MEM_POOLING_ERROR;
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] [FaultLentNode] Turn to memId fault deal error, "
                << "importNodeId=" << param.importNodeId << ", importMemId=" << param.memIdList[0] << ", uid"
                << param.uid << ", username=" << param.username << ".";
        }
    }
    return res;
}

uint32_t CheckUBTurboIsAliveHandler(const UbseByteBuffer& req, UbseByteBuffer& resp)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] CheckUBTurboIsAliveHandler start.";
    resp.len = 1;
    resp.data = new (std::nothrow) uint8_t[resp.len]{};
    if (resp.data == nullptr) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] Failed to allocate memory, size=" << resp.len << ".";
        return MEM_POOLING_ERROR;
    }
    resp.freeFunc = [](uint8_t* p) {
        if (p != nullptr) {
            delete[] p;
        }
    };
    turbo::rmrs::PidNumaInfoCollectParam pidNumaInfoCollectParam;
    turbo::rmrs::PidNumaInfoCollectResult pidNumaInfoCollectResult;
    auto ret = MempoolingMessage::rmrsPidNumaInfoCollect(pidNumaInfoCollectParam, pidNumaInfoCollectResult);
    if (ret == IPC_BAD_SOCKET || ret == IPC_BAD_CONNECT) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] UBTurbo is not alive, ret=" << ret << ".";
        resp.data[0] = static_cast<uint8_t>(0);
        return ret;
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] UBTurbo is alive, ret=" << ret << ".";
        resp.data[0] = static_cast<uint8_t>(1);
    }
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] CheckUBTurboIsAliveHandler end.";
    return ret;
}

MpResult IsAllOtherNodesWorkingOrFault(const std::string& nodeId)
{
    const auto allNodeInfo = UbseNodeController::GetInstance().GetAllNodes();
    for (const auto& [nId, nodeInfo] : allNodeInfo) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[EventHandler] nodeId=" << nId << " in state of " << static_cast<int>(nodeInfo.clusterState) << ".";
        if (nId != nodeId && nodeInfo.clusterState != UbseNodeClusterState::UBSE_NODE_WORKING &&
            nodeInfo.clusterState != UbseNodeClusterState::UBSE_NODE_FAULT) {
            // 账本不可靠: 存在状态未定(非working/fault)的其他节点，故障处理可能实际已成功;
            // 明细入带关键字[OvercommitFaultErr]的日志供grep检索，并按统一机制透传部分成功码(ret=8)
            std::vector<FaultErrorRecord> errRecords = {
                {MEM_POOLING_FAULT_PARTIAL_SUCCESS,
                 "detect node=" + nId + " in state=" + std::to_string(static_cast<int>(nodeInfo.clusterState)) +
                     " instead of working or fault; ledger unreliable(other nodes state uncertain), "
                     "fault handling may have actually succeeded, return partial success(ret=8)"}};
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultManager] " << JoinFaultErrorRecords(errRecords);
            return EarliestFaultErrorCode(errRecords);
        }
    }
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::FragmentHandleFault(std::string nodeId)
{
    faultHandleCurRound++;
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager] FragmentHandleFault round " << faultHandleCurRound << " start, nodeId=" << nodeId << ".";
    MpResult ret = IsAllOtherNodesWorkingOrFault(nodeId);
    MpResult res = BorrowRecordHelper::Instance().UpdateBorrowRecordsWithFragmentFault(nodeId);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] UpdateBorrowRecordsWithFragmentFault failed, nodeId=" << nodeId << " err=" << res << ".";
        return res;
    }

    NodeType nodeType = NodeType::ABNORMAL;
    res = FaultNodeModule::Instance().DetermineNodeTypeFragment(nodeId, nodeType);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] DetermineNodeTypeFragment failed, nodeId=" << nodeId << " err=" << res << ".";
        return res;
    }
    if (nodeType == NodeType::BORROW_IN) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] BORROW_IN Fault is handled by ubse, nodeId=" << nodeId << ".";
        return MEM_POOLING_OK;
    } else if (nodeType == NodeType::BORROW_OUT) {
        res = FaultNodeModule::Instance().ProcessBorrowOutNodeFaultParallel(nodeId, true);
        if (res != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] ProcessBorrowOutNodeFaultParallel failed, nodeId=" << nodeId << " err=" << res
                << ".";
            return res;
        } else {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager] ProcessBorrowOutNodeFaultParallel success, nodeId=" << nodeId << ".";
        }

    } else {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager] No actionable node type (NodeType=" << static_cast<int>(nodeType)
            << "), nodeId=" << nodeId << ", letting retry mechanism handle.";
    }
    return ret;
}

static void PrintCollectedInfos(const std::vector<BorrowGroupResult>& borrowGroups,
                                const std::vector<ClusterSnapshotItem>& baseSnapshot)
{
    // 打印 borrowGroups 详情
    for (const auto& group : borrowGroups) {
        // 构建虚机信息字符串
        std::string vmInfoStr;
        for (const auto& vm : group.vmInfos) {
            if (!vmInfoStr.empty())
                vmInfoStr += ", ";
            vmInfoStr +=
                "{pid:" + std::to_string(vm.pid) + ",remoteNumaUsedMem:" + std::to_string(vm.remoteNumaUsedMem) + "KB}";
        }
        // 构建账本信息字符串 —— 直接使用 BorrowRecord 的 ToString()
        std::string recordStr;
        for (const auto& rec : group.records) {
            if (!recordStr.empty())
                recordStr += ", ";
            recordStr += rec.ToString();
        }
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][FaultHandleInfosCollect] BorrowGroup: borrowNode=" << group.borrowNodeId
            << ", faultNuma=" << group.remoteNumaId << ", borrowSocket=" << group.borrowSocketId
            << ", totalSize=" << group.totalSize << "KB"
            << ", totalUsedSize=" << group.totalUsedSize << "KB"
            << ", vmInfos=[" << vmInfoStr << "]"
            << ", borrowRecords=[" << recordStr << "]"
            << ", strategy=" << static_cast<int>(group.strategyType) << ".";
    }

    // 打印集群快照 baseSnapshot
    for (const auto& item : baseSnapshot) {
        std::string numaDetails;
        for (const auto& [numaId, blocks] : item.numaCanLentMap) {
            if (!numaDetails.empty())
                numaDetails += ", ";
            numaDetails += "numa" + std::to_string(numaId) + ":" +
                           std::to_string(blocks * FaultNodeModule::GetBlockSizeKB()) + "KB";
        }
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][FaultHandleInfosCollect] ClusterSnapshot: node=" << item.nodeId
            << ", socket=" << item.socketId << ", canLentTotal=" << item.canLentMemSize << "KB"
            << ", numaDetails=[" << numaDetails << "]";
    }
}

// 按故障Numa（即borrowNodeId+remoteNumaId）分组
std::vector<BorrowGroupResult> FaultNodeModule::GroupBorrowRecordsByNuma(const std::vector<BorrowRecord>& records)
{
    std::unordered_map<std::string, BorrowGroupResult> groupMap;
    for (const auto& rec : records) {
        std::string key = rec.borrowNode + "_" + std::to_string(rec.borrowRemoteNuma);
        auto& group = groupMap[key];
        if (group.borrowNodeId.empty()) {
            group.borrowNodeId = rec.borrowNode;
            group.remoteNumaId = rec.borrowRemoteNuma;
            group.borrowSocketId = rec.borrowSocketId;
        }
        group.totalSize += rec.size;
        group.records.push_back(rec);
    }
    std::vector<BorrowGroupResult> groups;
    for (auto& [_, g] : groupMap) {
        std::sort(g.records.begin(), g.records.end(),
                  [](const BorrowRecord& a, const BorrowRecord& b) { return a.size > b.size; });
        groups.push_back(std::move(g));
    }
    std::sort(groups.begin(), groups.end(),
              [](const BorrowGroupResult& a, const BorrowGroupResult& b) { return a.totalSize > b.totalSize; });
    return groups;
}

// 向借入节点发起RPC，获取占用指定远端Numa的所有虚机信息
MpResult FaultNodeModule::GetVmOccupancyForGroup(const std::string& borrowNodeId, uint16_t remoteNumaId,
                                                 std::vector<FaultNumaVmInfo>& vmInfos)
{
    // 复用 OverCommitMsg::GetVmNumaInfoMapRpc，但该接口根据本地 numa 获取虚机，需要二次筛选
    std::vector<mempooling::VmNumaInfoWithSocket> allVms;
    MpResult ret = OverCommitFaultMemIdModule::Instance().GetVmNumaInfoMapRpc(borrowNodeId, allVms, remoteNumaId);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandlePara] GetVmNumaInfoMapRpc failed, borrowNodeId=" << borrowNodeId << ".";
        return ret;
    }
    for (const auto& v : allVms) {
        // 只保留占用了该远端 numa 的虚机（即remoteNumaId匹配）
        if (v.remoteNumaId == remoteNumaId && v.remoteUsedMem > 0) {
            FaultNumaVmInfo info;
            info.pid = v.pid;
            info.localNumaId = v.localNumaId;
            info.remoteNumaId = v.remoteNumaId;
            info.remoteNumaUsedMem = v.remoteUsedMem;
            vmInfos.push_back(info);
        }
    }

    if (vmInfos.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandlePara] GetVmInfos for Group failed, vmInfos empty, borrowNodeId=" << borrowNodeId
            << ", remoteNumaId=" << remoteNumaId << ".";
        return MEM_POOLING_OK;
    }
    std::sort(vmInfos.begin(), vmInfos.end(), [](const FaultNumaVmInfo& a, const FaultNumaVmInfo& b) {
        return a.remoteNumaUsedMem > b.remoteNumaUsedMem;
    });
    return MEM_POOLING_OK;
}

// 从候选列表中 Best-Fit 分配 needBlocks 个block
// samePlaneOnly: true 只考虑同平面；false 优先同平面，若同平面无可用则考虑其他平面
// 成功返回true，result.selected:指向选中的节点；result.allocatedNumas:记录每个numa分配了多少block
bool FaultNodeModule::TryBestFitAllocate(const BorrowGroupResult& group,
                                         const std::vector<ClusterSnapshotItem*>& candidates, uint64_t needBlocks,
                                         bool samePlaneOnly,
                                         AllocResult& result) // 输出参数
{
    result.allocatedNumas.clear();
    if (candidates.empty()) {
        return false;
    }

    // 复制候选列表并按 socket 的 canLentMemSize 升序排序（Best‑Fit 外层顺序）
    std::vector<ClusterSnapshotItem*> sortedSockets = candidates;
    std::sort(sortedSockets.begin(), sortedSockets.end(),
              [](const ClusterSnapshotItem* a, const ClusterSnapshotItem* b) {
                  return a->canLentMemSize < b->canLentMemSize;
              });

    for (auto* socket : sortedSockets) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] Try lentNodeId=" << socket->nodeId << ", socketId=" << socket->socketId << ".";
        // 同平面过滤（如果需要）
        if (samePlaneOnly) {
            bool isSamePlane = MemManager::Instance().JudgeSampPlane(socket->nodeId, socket->socketId,
                                                                     group.borrowNodeId, group.borrowSocketId);
            if (!isSamePlane) {
                UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[FaultHandleParallel] Not samePlane,skip. lentNodeId=" << socket->nodeId
                    << ", socketId=" << socket->socketId << ".";
                continue;
            }
        }

        // 将当前 socket 下的所有 numa 按可用 block 数升序排序（实现numa级别的Best‑Fit）
        std::vector<std::pair<uint16_t, uint64_t>> numaList(socket->numaCanLentMap.begin(),
                                                            socket->numaCanLentMap.end());
        std::sort(numaList.begin(), numaList.end(),
                  [](const auto& a, const auto& b) { return a.second < b.second; }); // 升序

        for (auto& [numaId, blocks] : numaList) {
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] Try lentNodeId=" << socket->nodeId << ", socketId=" << socket->socketId
                << ", numaId=" << numaId << ",blocks=" << blocks << ", needBlocks=" << needBlocks << ".";
            if (blocks >= needBlocks) {
                // 找到合适的 numa，执行分配
                result.selected = socket;
                // 从该 numa 扣减
                socket->numaCanLentMap[numaId] = blocks - needBlocks;
                result.allocatedNumas.emplace_back(numaId, needBlocks); // 记录分配
                // 更新 socket 级别的总 block 数
                socket->totalBlocks -= needBlocks;
                socket->canLentMemSize = socket->totalBlocks * sBlockSizeKb;
                UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[FaultHandleParallel] Find success. lentNodeId=" << socket->nodeId
                    << ", socketId=" << socket->socketId << ", numaId=" << numaId << ",blocks=" << blocks
                    << ", needBlocks=" << needBlocks << ".";
                return true;
            }
        }
    }
    return false;
}

// 获取基础集群快照：只包含健康、非借入节点，按 socket 聚合，block 对齐，升序排序
MpResult FaultNodeModule::GetBaseClusterSnapshot(const std::string& faultNodeId,
                                                 std::vector<ClusterSnapshotItem>& clusterInfos)
{
    const uint64_t blockSize = sBlockSizeKb;

    // 1. 获取初始可借节点列表（基础过滤：工作状态、非借入节点等）
    std::vector<std::string> borrowAbleNodeIdList;
    MpResult res = GetBorrowAbleNodeIdList(faultNodeId, borrowAbleNodeIdList);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[GetBaseClusterSnapshot] GetBorrowAbleNodeIdList failed, faultNodeId=" << faultNodeId << " err=" << res
            << ".";
        return res;
    }
    if (borrowAbleNodeIdList.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[GetBaseClusterSnapshot] No candidate nodes for fault node " << faultNodeId;
        return MEM_POOLING_OK;
    }

    // 2. 获取这些节点的内存信息（按socket聚合）
    std::vector<NodeMemoryInfoWithReservedMem> ableNodeMemInfoList;
    res = GetBorrowAbleNodeInfoSortByMemSize(borrowAbleNodeIdList, ableNodeMemInfoList);
    if (res != MEM_POOLING_OK || ableNodeMemInfoList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[GetBaseClusterSnapshot] GetBorrowAbleNodeInfoSortByMemSize failed, faultNodeId=" << faultNodeId
            << " err=" << res << ".";
        return res;
    }

    // 3. 转换为 ClusterSnapshotItem，并按 blockSize 对齐
    for (const auto& nodeInfo : ableNodeMemInfoList) {
        ClusterSnapshotItem item;
        item.nodeId = nodeInfo.nodeId;
        item.socketId = nodeInfo.socketId;
        item.freeMemSize = nodeInfo.canBorrowMem;
        item.totalBlocks = 0;
        for (const auto& numa : nodeInfo.numaMemInfo) {
            item.numaIds.push_back(numa.numaId);
            uint64_t blocks = numa.canBorrowMem / blockSize;
            if (blocks > 0) {
                item.numaCanLentMap[numa.numaId] = blocks;
                item.totalBlocks += blocks;
            }
        }
        item.canLentMemSize = item.totalBlocks * blockSize;
        if (item.totalBlocks > 0) {
            clusterInfos.push_back(item);
        }
    }

    // 4. 按 canLentMemSize 升序排序
    std::sort(clusterInfos.begin(), clusterInfos.end(), [](const ClusterSnapshotItem& a, const ClusterSnapshotItem& b) {
        return a.canLentMemSize < b.canLentMemSize;
    });

    return MEM_POOLING_OK;
}

// 根据借入节点ID和socketId对集群快照进行动态过滤，返回候选节点指针列表
std::vector<ClusterSnapshotItem*> FaultNodeModule::FilterSnapshotByBorrowNode(
    const std::string& borrowNodeId, uint16_t borrowSocketId, std::vector<ClusterSnapshotItem>& clusterInfos)
{
    std::vector<ClusterSnapshotItem*> candidates;

    // 1. 获取白名单
    std::unordered_set<std::string> couldBorrowNodeSet;
    MpResult ret = MpParseGroupProviderConf::Instance().GetBorrowableList(borrowNodeId, couldBorrowNodeSet);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FilterSnapshot] GetBorrowableList failed for node " << borrowNodeId << ".";
        return candidates;
    }

    // 2. 反亲和节点
    std::vector<std::string> antiNodeVec;
    AntiNode::Instance().Query(borrowNodeId, antiNodeVec);
    for (const auto& antiNode : antiNodeVec) {
        couldBorrowNodeSet.erase(antiNode);
    }

    // 3. 成环过滤：排除自身是借入节点的节点（即不能向也借入了内存的节点借用）
    std::vector<BorrowRecord> borrowRecords;
    ret = BorrowRecordHelper::Instance().CollectBorrowRecordsAll(borrowRecords, true, true);
    if (ret == MEM_POOLING_OK) {
        for (const auto& record : borrowRecords) {
            couldBorrowNodeSet.erase(record.borrowNode);
        }
    }

    // 4. 归还超时记录过滤
    std::unordered_map<std::string, BorrowItem> borrowCacheAll;
    MemReturnManager::Instance().QueryAll(borrowCacheAll);
    for (const auto& kv : borrowCacheAll) {
        if (kv.second.srcNid == borrowNodeId &&
            MemManager::Instance().JudgeSampPlane(borrowNodeId, borrowSocketId, kv.second.dstNid,
                                                  kv.second.dstSocketId)) {
            couldBorrowNodeSet.erase(kv.second.dstNid);
        }
    }

    // 5. 筛选clusterInfos中满足白名单的节点
    for (auto& item : clusterInfos) {
        if (couldBorrowNodeSet.find(item.nodeId) != couldBorrowNodeSet.end()) {
            candidates.push_back(&item);
        }
    }
    return candidates;
}

void FaultNodeModule::NumaLevelDecisionFill(BorrowGroupResult& group, ClusterSnapshotItem& best, uint64_t needBlocks,
                                            std::vector<std::pair<uint16_t, uint64_t>>& allocatedNumas)
{
    NumaLevelDecision decision;
    if (group.records.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[NumaLevelDecision] group.records is empty, skip filling numa-level decision.";
        return;
    }
    for (const auto& record : group.records) {
        decision.oldNames.push_back(record.name);
    }
    decision.borrowNumaId = group.records[0].borrowLocalNuma;
    decision.borrowSocketId = group.records[0].borrowSocketId;
    decision.lentNodeId = best.nodeId;
    decision.lentSocketId = best.socketId;
    decision.borrowSize = needBlocks * sBlockSizeKb;
    for (auto [numaId, blocks] : allocatedNumas) {
        decision.lentNumaId = numaId;
        decision.lentMemSize = blocks * sBlockSizeKb;
        decision.lentNumaIdAndSizeMap[numaId] = blocks * sBlockSizeKb;
    }
    for (const auto& vm : group.vmInfos) {
        decision.pids.push_back(vm.pid);
    }
    RemoveMigratedPidsFromVmInfos(group.vmInfos, decision.pids);
    if (!group.records.empty()) {
        decision.uid = group.records[0].uid;
        decision.username = group.records[0].username;
    }
    group.numaDecision = decision;
}

static void printNumaLevelDecisions(const std::vector<BorrowGroupResult>& borrowGroups, int successCnt)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[NumaLevelDecision] Total groups=" << borrowGroups.size()
                                                     << ", numa-level strategy success count=" << successCnt << ".";

    for (const auto& group : borrowGroups) {
        if (group.strategyType != BorrowStrategyType::NUMA_LEVEL_STRATEGY) {
            continue;
        }

        const auto& decision = group.numaDecision;
        std::string oldNamesStr;
        std::string pidsStr;
        for (size_t i = 0; i < decision.oldNames.size(); ++i) {
            if (i != 0)
                oldNamesStr += ",";
            oldNamesStr += decision.oldNames[i];
        }

        if (decision.isReturnDirectly == true) {
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[NumaLevelDecision] BorrowGroup borrowNodeId=" << group.borrowNodeId
                << ", faultNuma=" << group.remoteNumaId << " generate numa-level decision success. "
                << "Decide to return directly oldNames=[" << oldNamesStr << "].";
            continue;
        }

        for (size_t i = 0; i < decision.pids.size(); ++i) {
            if (i != 0)
                pidsStr += ",";
            pidsStr += std::to_string(decision.pids[i]);
        }
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[NumaLevelDecision] BorrowGroup borrowNodeId=" << group.borrowNodeId
            << ", faultNuma=" << group.remoteNumaId << " generate numa-level decision success. "
            << "Decision: borrow from lentNodeId=" << decision.lentNodeId << ", lentSocketId=" << decision.lentSocketId
            << ", lentNumaId=" << decision.lentNumaId << ", lentMemSize=" << decision.lentMemSize << "KB"
            << ", migrate these pids=[" << pidsStr << "]"
            << ", return oldNames=[" << oldNamesStr << "].";
    }
}

void FaultNodeModule::GenerateNumaLevelDecision(std::vector<BorrowGroupResult>& borrowGroups,
                                                std::vector<ClusterSnapshotItem>& baseSnapshot, bool mustSamePlane)
{
    int successCnt = 0;
    for (auto& group : borrowGroups) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] start to generate numa-level decision for borrowGroup which's borrowNodeId="
            << group.borrowNodeId << ", faultNumaId=" << group.remoteNumaId << ".";
        if (group.strategyType == BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] This borrowGroup was borrowed and strategy is borrowIdLevel.";
            continue;
        }
        if (group.strategyType == BorrowStrategyType::NUMA_LEVEL_STRATEGY && group.numaDecision.isBorrowed) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel] this borrowGroup was borrowed.";
            successCnt++; // 计入成功（已执行借用过但迁移失败的决策）
            continue;
        }

        if (group.vmInfos.empty()) {
            group.strategyType = BorrowStrategyType::NUMA_LEVEL_STRATEGY;
            group.numaDecision.isReturnDirectly = true;
            for (const auto& record : group.records) {
                group.numaDecision.oldNames.push_back(record.name);
            }
            successCnt++;
            continue;
        }

        // 1. 动态过滤，得到该borrowNode的候选节点列表
        auto candidates = FilterSnapshotByBorrowNode(group.borrowNodeId, group.borrowSocketId, baseSnapshot);
        if (candidates.empty()) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[NumaLevelDecision] No candidates for borrowNode " << group.borrowNodeId << ".";
            continue;
        }

        // 2. 使用 group.totalSize 计算 needBlocks（账本总借用大小）
        uint64_t needBlocks = (group.totalSize + GetBlockSizeKB() - 1) / GetBlockSizeKB();
        AllocResult allocResult;
        bool allocateSuccess = false;

        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] borrowGroup which's borrowNodeId=" << group.borrowNodeId
            << ", faultNumaId=" << group.remoteNumaId << ", needBlocks=" << needBlocks << ".";

        // 同平面决策
        if (TryBestFitAllocate(group, candidates, needBlocks, true, allocResult)) {
            allocateSuccess = true;
        }
        // 不限制同平面 且 同平面下借用决策失败，尝试非同平面借用决策
        if (!mustSamePlane && !allocateSuccess) {
            if (TryBestFitAllocate(group, candidates, needBlocks, false, allocResult)) {
                allocateSuccess = true;
            }
        }
        if (!allocateSuccess) {
            // 决策失败则跳过该故障numa到下一个，该故障numa继续再borrowId-level进行借用决策
            continue;
        }

        // 填充决策结果
        group.strategyType = BorrowStrategyType::NUMA_LEVEL_STRATEGY;
        successCnt++;
        NumaLevelDecisionFill(group, *allocResult.selected, needBlocks, allocResult.allocatedNumas);
    }

    printNumaLevelDecisions(borrowGroups, successCnt);
}

void FaultNodeModule::RemoveMigratedPidsFromVmInfos(std::vector<FaultNumaVmInfo>& vmInfos,
                                                    const std::vector<pid_t>& pids)
{
    for (pid_t pid : pids) {
        auto it =
            std::find_if(vmInfos.begin(), vmInfos.end(), [pid](const FaultNumaVmInfo& vm) { return vm.pid == pid; });
        if (it != vmInfos.end()) {
            vmInfos.erase(it);
        }
    }
}

void FaultNodeModule::GenerateBorrowIdLevelDecision(std::vector<BorrowGroupResult>& borrowGroups,
                                                    std::vector<ClusterSnapshotItem>& baseSnapshot, bool mustSamePlane)
{
    for (auto& group : borrowGroups) {
        if (group.strategyType == BorrowStrategyType::NUMA_LEVEL_STRATEGY) {
            continue;
        }

        // 复制已有的已借用决策，并构建 oldName -> BorrowIdLevelDecision 映射
        std::vector<BorrowIdLevelDecision> tmpDecisions;
        std::map<std::string, BorrowIdLevelDecision> borrowedMap;
        for (const auto& dec : group.borrowIdDecisions) {
            if (dec.isBorrowed) {
                tmpDecisions.push_back(dec);
                borrowedMap[dec.oldName] = dec;
                UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[FaultHandleParallel] BorrowedDecision oldName=" << dec.oldName << ".";
            }
        }

        // 动态过滤
        auto candidates = FilterSnapshotByBorrowNode(group.borrowNodeId, group.borrowSocketId, baseSnapshot);
        if (candidates.empty()) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[BorrowIdLevelDecision] No candidates for borrowNode " << group.borrowNodeId << ".";
            continue;
        }

        int errCount = 0;
        for (const auto& record : group.records) {
            // 如果已借用过该 record，从 vmInfos 中删除对应的 pids，并跳过
            auto it = borrowedMap.find(record.name);
            if (it != borrowedMap.end()) {
                UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[BorrowIdLevelDecision] Skip already borrowed record, oldName=" << record.name << ".";
                // 删除该决策中需要迁移的 pid 集合
                const auto& pidsToRemove = it->second.borrowedDecision.pids;
                RemoveMigratedPidsFromVmInfos(group.vmInfos, pidsToRemove);
                continue;
            }

            BorrowIdLevelDecision decision;
            decision.oldName = record.name;
            // 当故障numa上没有虚机占用，且前面的决策没有失败的情况下，直接归还该oldBorrowId
            if (group.vmInfos.empty() && errCount == 0) {
                decision.isReturnDirectly = true;
                tmpDecisions.push_back(decision);
                continue;
            }

            if (!group.records.empty()) {
                decision.uid = group.records[0].uid;
                decision.username = group.records[0].username;
            }

            // 转换虚机信息格式
            std::vector<VmNumaInfo> tmp;
            for (const auto& vm : group.vmInfos) {
                tmp.push_back({vm.pid, vm.localNumaId, vm.remoteNumaId, 0, vm.remoteNumaUsedMem});
            }
            std::vector<pid_t> pids;
            uint64_t needBorrowSize = 0;
            MpResult ret =
                FaultMemIdModule::Instance().FindClosestVmForMemAlloc(tmp, record.size, pids, needBorrowSize);
            if (ret != MEM_POOLING_OK || needBorrowSize == 0) {
                continue;
            }

            uint64_t needBlocks = (needBorrowSize + sBlockSizeKb - 1) / sBlockSizeKb;
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] borrowGroup which's borrowNodeId=" << group.borrowNodeId
                << ", faultNumaId=" << group.remoteNumaId << ", needBorrowSize=" << needBorrowSize
                << ", needBlocks=" << needBlocks << ".";
            needBorrowSize = needBlocks * sBlockSizeKb;

            AllocResult allocResult;
            bool allocateSuccess = false;
            if (TryBestFitAllocate(group, candidates, needBlocks, true, allocResult)) {
                allocateSuccess = true;
            }
            if (!mustSamePlane && !allocateSuccess) {
                if (TryBestFitAllocate(group, candidates, needBlocks, false, allocResult)) {
                    allocateSuccess = true;
                }
            }
            if (!allocateSuccess) {
                errCount++;
                continue;
            }
            decision.oldName = record.name;
            decision.borrowNumaId = record.borrowLocalNuma;
            decision.borrowSocketId = record.borrowSocketId;
            decision.needBorrowSize = needBorrowSize;
            decision.pids = pids;
            decision.lentNodeId = allocResult.selected->nodeId;
            decision.lentSocketId = allocResult.selected->socketId;
            for (auto [numaId, block] : allocResult.allocatedNumas) {
                decision.lentNumaId = numaId;
                decision.lentMemSize = block * sBlockSizeKb;
                decision.lentNumaIdAndSizeMap.emplace(numaId, block * sBlockSizeKb);
            }
            tmpDecisions.push_back(decision);
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] borrowIdDecision tmp generate success. {oldName=" << decision.oldName
                << " borrow from lentNodeId=" << decision.lentNodeId << ", lentSocketId=" << decision.lentSocketId
                << ", lentNumaId=" << decision.lentNumaId << ", lentMemSize=" << decision.lentMemSize << "KB}";

            RemoveMigratedPidsFromVmInfos(group.vmInfos, decision.pids);
        }
        // 排序
        std::stable_sort(tmpDecisions.begin(), tmpDecisions.end(),
                         [](const BorrowIdLevelDecision& a, const BorrowIdLevelDecision& b) {
                             // 非直接归还（false）的决策排在直接归还（true） 前面
                             return a.isReturnDirectly < b.isReturnDirectly;
                         });
        group.borrowIdDecisions = std::move(tmpDecisions);
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] group.borrowIdDecisions.size=" << group.borrowIdDecisions.size() << ".";
        group.strategyType = (group.borrowIdDecisions.empty()) ? BorrowStrategyType::STRATEGY_FAILED :
                                                                 BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY;
    }
}

static void printBorrowIdLevelDecisions(const std::vector<BorrowGroupResult>& borrowGroups)
{
    int borrowIdCount = 0;
    for (const auto& group : borrowGroups) {
        if (group.strategyType == BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY) {
            borrowIdCount++;
        }
    }
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] borrowIdDecisionGroup count=" << borrowIdCount << ".";

    for (const auto& group : borrowGroups) {
        if (group.strategyType != BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY) {
            continue;
        }

        std::string decisionsStr;
        for (const auto& decision : group.borrowIdDecisions) {
            if (!decisionsStr.empty()) {
                decisionsStr += ", ";
            }
            if (decision.isReturnDirectly) {
                decisionsStr += "{oldName=" + decision.oldName + " : isReturnDirectly=true}";
            } else {
                decisionsStr += "{oldName=" + decision.oldName + " borrow from lentNodeId=" + decision.lentNodeId +
                                ", lentSocketId=" + std::to_string(decision.lentSocketId) +
                                ", lentNumaId=" + std::to_string(decision.lentNumaId) +
                                ", lentMemSize=" + std::to_string(decision.lentMemSize) + "KB}";
            }
        }

        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelDecision] BorrowGroup: borrowNodeId=" << group.borrowNodeId
            << ", faultNuma=" << group.remoteNumaId << ", totalRecords=" << group.records.size()
            << ", decisionsGenerated=" << group.borrowIdDecisions.size() << ", Decisions:[" << decisionsStr << "].";
    }
}

MpResult FaultNodeModule::FaultHandleBorrowStrategy(std::vector<BorrowGroupResult>& borrowGroups,
                                                    std::vector<ClusterSnapshotItem>& baseSnapshot)
{
    // 确保基础快照升序（已在 GetBaseClusterSnapshot 中完成，这里再确保一次）
    bool mustSamePlane = MpConfiguration::GetInstance().GetMustSamePlane();

    // 1. NUMA 级别决策
    GenerateNumaLevelDecision(borrowGroups, baseSnapshot, mustSamePlane);
    PrintCollectedInfos(borrowGroups, baseSnapshot);

    // 2. BorrowId 级别决策
    GenerateBorrowIdLevelDecision(borrowGroups, baseSnapshot, mustSamePlane);
    // 打印 BorrowId 级别决策
    printBorrowIdLevelDecisions(borrowGroups);
    PrintCollectedInfos(borrowGroups, baseSnapshot);

    // 统计完全失败的组数
    int totalFailed = 0;
    for (const auto& group : borrowGroups) {
        if (group.strategyType == BorrowStrategyType::STRATEGY_FAILED) {
            totalFailed++;
        }
    }
    if (totalFailed == (int)borrowGroups.size()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel][FaultHandleBorrowStrategy] All "
                                                             "BorrowGroups generate strategy failed, totalGroups="
                                                          << borrowGroups.size() << ".";
        borrowGroups.clear();
        return MEM_POOLING_FAULT_LACK_REMOTE_MEM_ERROR;
    }

    if (totalFailed > 0) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][FaultHandleBorrowStrategy] totalFailed count=" << totalFailed << " out of "
            << borrowGroups.size() << " groups.";
        return MEM_POOLING_FAULT_LACK_REMOTE_MEM_ERROR;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][FaultHandleBorrowStrategy] All BorrowGroups generate strategy successfully.";
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::GetBorrowedDecisionRpc(const std::string& nodeId, std::vector<BorrowedDecision>& outDecisions)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] SendGetBorrowedDecisionRpc to node " << nodeId << ".";
    UbseComEndpoint endpoint = {
        .moduleId = MP_MODULE_CODE, .serviceId = message::OPCODE_GET_BORROWED_DECISION, .address = nodeId};
    RmrsOutStream builder;
    builder << nodeId;
    UbseByteBuffer reqData = {
        .data = builder.GetBufferPointer(), .len = builder.GetSize(), .freeFunc = [](uint8_t* data) {
            delete[] data;
        }};

    uint32_t rpcRet = UbseRpcSend(endpoint, reqData, &outDecisions, GetBorrowedDecisionResHandler);
    if (rpcRet != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "SendGetBorrowedDecisionRpc RPC send failed, ret=" << rpcRet;
        return MEM_POOLING_ERROR;
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] GetBorrowedDecisionRpc received " << outDecisions.size() << " decisions.";

    return MEM_POOLING_OK;
}

void GetBorrowedDecisionResHandler(void* ctx, const UbseByteBuffer& respData, uint32_t resCode)
{
    if (ctx == nullptr || respData.data == nullptr || respData.len == 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[GetBorrowedDecisionResHandler] Invalid param";
        return;
    }
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[GetBorrowedDecisionResHandler] resCode=" << resCode << ", respLen=" << respData.len;

    auto* result = static_cast<std::vector<BorrowedDecision>*>(ctx);
    if (resCode != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[GetBorrowedDecisionResHandler] RPC error, resCode=" << resCode;
        return;
    }

    // 反序列化决策列表
    RmrsInStream in(respData.data, respData.len);
    in >> *result;

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[GetBorrowedDecisionResHandler] Received " << result->size() << " decisions.";
}

// 构造本轮实采的身份集合：故障 numa 上当前的虚机 pid 与旧借用 oldName
static void CollectGroupIdentity(const BorrowGroupResult& group, std::unordered_set<pid_t>& curPids,
                                 std::unordered_set<std::string>& curOldNames)
{
    for (const auto& vm : group.vmInfos) {
        curPids.insert(vm.pid);
    }
    for (const auto& record : group.records) {
        curOldNames.insert(record.name);
    }
}

bool IsNumaLevelDecisionMatchGroup(const BorrowGroupResult& group, const NumaLevelBorrowedDecision& decision)
{
    std::unordered_set<pid_t> curPids;
    std::unordered_set<std::string> curOldNames;
    CollectGroupIdentity(group, curPids, curOldNames);

    bool pidHit = std::any_of(decision.pids.begin(), decision.pids.end(),
                              [&curPids](pid_t pid) { return curPids.count(pid) > 0; });
    bool oldNameHit = std::any_of(decision.borrowResultMap.begin(), decision.borrowResultMap.end(),
                                  [&curOldNames](const auto& kv) { return curOldNames.count(kv.first) > 0; });
    return pidHit && oldNameHit;
}

bool IsBorrowIdLevelDecisionMatchGroup(const BorrowGroupResult& group, const BorrowIdLevelBorrowedDecision& decision)
{
    std::unordered_set<pid_t> curPids;
    std::unordered_set<std::string> curOldNames;
    CollectGroupIdentity(group, curPids, curOldNames);

    bool pidHit = std::any_of(decision.pids.begin(), decision.pids.end(),
                              [&curPids](pid_t pid) { return curPids.count(pid) > 0; });
    bool oldNameHit = curOldNames.count(decision.oldName) > 0;
    return pidHit && oldNameHit;
}

bool IsBorrowedDecisionAlive(const BorrowedDecision& decision)
{
    // 一次实时采集账本快照，循环内本地查找，避免逐 newName 重复 IPC
    std::vector<BorrowRecord> records;
    if (BorrowRecordHelper::Instance().FetchBorrowRecords(records) != MEM_POOLING_OK) {
        // fail-safe：账本采集失败时视为存活，避免误删存活决策导致新借用泄漏
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] Fetch ledger failed in IsBorrowedDecisionAlive, fail-safe keep decision, "
            << "remoteNumaId=" << decision.remoteNumaId << ".";
        return true;
    }
    if (decision.isNumaLevel) {
        for (const auto& [oldName, newName] : decision.numaBorrowedDecision.borrowResultMap) {
            if (BorrowRecordHelper::BorrowIdExistsIn(records, newName)) {
                return true;
            }
        }
        return false;
    }
    for (const auto& bdec : decision.borrowIdBorrowedDecisions) {
        if (BorrowRecordHelper::BorrowIdExistsIn(records, bdec.newName)) {
            return true;
        }
    }
    return false;
}

bool IsBorrowedDecisionAlive(const BorrowedDecision& decision, const std::vector<BorrowRecord>& records)
{
    if (decision.isNumaLevel) {
        for (const auto& [oldName, newName] : decision.numaBorrowedDecision.borrowResultMap) {
            if (BorrowRecordHelper::BorrowIdExistsIn(records, newName)) {
                return true;
            }
        }
        return false;
    }
    for (const auto& bdec : decision.borrowIdBorrowedDecisions) {
        if (BorrowRecordHelper::BorrowIdExistsIn(records, bdec.newName)) {
            return true;
        }
    }
    return false;
}

uint32_t GetBorrowedDecisionHandler(const UbseByteBuffer& req, UbseByteBuffer& resp)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel] GetBorrowedDecisionHandler start.";

    std::vector<BorrowedDecision> decisionList;
    MpResult ret = FaultHandleBorrowedDecision::Instance().QueryAll(decisionList);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel] QueryAll failed, ret=" << ret;
        resp.len = sizeof(MpResult);
        resp.data = new (std::nothrow) uint8_t[resp.len];
        if (resp.data == nullptr) {
            LOG_ERROR << "[FaultHandleParallel] Out of memory.";
            return MEM_POOLING_ERROR;
        }
        resp.freeFunc = [](uint8_t* data) {
            delete[] data;
        };
        *reinterpret_cast<MpResult*>(resp.data) = ret;
        return MEM_POOLING_ERROR;
    }

    // 用前自愈：newName 已不在账本 = 新借用已被正常归还流程释放，present numa 已消失，决策已陈旧。
    // 若继续下发，master 会按故障 numa 匹配并让借入节点续做已消失的 present numa，导致迁移失败(ret=99)。
    // 此处在源头剔除并删除这类孤儿决策，使该故障 numa 回退为重新借用。
    std::vector<BorrowRecord> ledgerRecords;
    bool ledgerFetched = BorrowRecordHelper::Instance().FetchBorrowRecords(ledgerRecords) == MEM_POOLING_OK;
    if (!ledgerFetched) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] Fetch ledger failed, fail-safe keep all decisions.";
    }
    std::vector<BorrowedDecision> aliveDecisions;
    aliveDecisions.reserve(decisionList.size());
    for (auto& dec : decisionList) {
        if (!ledgerFetched || IsBorrowedDecisionAlive(dec, ledgerRecords)) {
            aliveDecisions.push_back(std::move(dec));
            continue;
        }
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] Drop stale borrowed decision (newName already returned), remoteNumaId="
            << dec.remoteNumaId << ", decision=" << dec.ToString() << ".";
        FaultHandleBorrowedDecision::Instance().Remove(dec.remoteNumaId);
    }

    // 序列化存活决策列表
    RmrsOutStream builder;
    builder << aliveDecisions;
    resp.len = builder.GetSize();
    resp.data = builder.GetBufferPointer();
    resp.freeFunc = [](uint8_t* data) {
        delete[] data;
    };

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] Success, returned " << aliveDecisions.size() << " decisions.";
    return MEM_POOLING_OK;
}

void FaultNodeModule::RebuildBorrowGroup(std::vector<BorrowGroupResult>& borrowGroups)
{
    // 按 borrowNodeId 聚合组，减少 RPC 次数
    std::unordered_map<std::string, std::vector<size_t>> nodeToGroupIndices;
    for (size_t i = 0; i < borrowGroups.size(); ++i) {
        nodeToGroupIndices[borrowGroups[i].borrowNodeId].push_back(i);
    }
    // 对每个节点发起一次 RPC 获取该节点上所有失败决策
    for (auto& kv : nodeToGroupIndices) {
        const std::string& nodeId = kv.first;
        std::vector<BorrowedDecision> nodeDecisions;
        if (GetBorrowedDecisionRpc(nodeId, nodeDecisions) != MEM_POOLING_OK) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] RebuildBorrowGroup: Failed to get borrowed decisions from node=" << nodeId
                << ".";
            continue;
        }
        // 构建 remoteNumaId -> BorrowedDecision 的映射
        std::unordered_map<uint16_t, BorrowedDecision> numaDecisionMap;
        for (auto& dec : nodeDecisions) {
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] GetBorrowedDecision: Node=" << nodeId << ", remoteNumaId=" << dec.remoteNumaId
                << ", isNumaLevel=" << dec.isNumaLevel << ".";
            numaDecisionMap[dec.remoteNumaId] = std::move(dec);
        }
        // 更新对应的 borrowGroup
        for (size_t idx : kv.second) {
            auto& group = borrowGroups[idx];
            auto it = numaDecisionMap.find(group.remoteNumaId);
            if (it == numaDecisionMap.end())
                continue;
            const auto& borrowed = it->second;
            if (borrowed.isNumaLevel) {
                // NUMA 级别失败决策：需 (pid, oldName) 复合身份与本轮实采吻合才续做，否则判为陈旧孤儿、回退重决策
                if (!IsNumaLevelDecisionMatchGroup(group, borrowed.numaBorrowedDecision)) {
                    UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                        << "[FaultHandleParallel] Stale numa-level borrowed decision, skip RESUME and re-decide."
                        << " nodeId=" << nodeId << ", remoteNumaId=" << group.remoteNumaId
                        << ", decision=" << borrowed.numaBorrowedDecision.ToString() << ".";
                    continue;
                }
                group.strategyType = BorrowStrategyType::NUMA_LEVEL_STRATEGY;
                group.numaDecision.isBorrowed = true;
                group.numaDecision.borrowedDecision = borrowed.numaBorrowedDecision;
            } else {
                // borrowId 级别失败决策：逐条按 (pid, oldName) 复合身份过滤陈旧项
                group.borrowIdDecisions.clear();
                for (const auto& bdec : borrowed.borrowIdBorrowedDecisions) {
                    if (!IsBorrowIdLevelDecisionMatchGroup(group, bdec)) {
                        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                            << "[FaultHandleParallel] Stale borrowId-level borrowed decision, skip RESUME."
                            << " nodeId=" << nodeId << ", oldName=" << bdec.oldName << ", decision=" << bdec.ToString()
                            << ".";
                        continue;
                    }
                    BorrowIdLevelDecision dec;
                    dec.oldName = bdec.oldName;
                    dec.isBorrowed = true;
                    dec.borrowedDecision = bdec;
                    group.borrowIdDecisions.push_back(dec);
                }
                if (group.borrowIdDecisions.empty()) {
                    // 全部陈旧 → 保持 STRATEGY_FAILED，交由决策层重新生成
                    UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                        << "[FaultHandleParallel] All borrowId-level decisions stale, fallback to re-decide."
                        << " nodeId=" << nodeId << ", remoteNumaId=" << group.remoteNumaId << ".";
                    continue;
                }
                group.strategyType = BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY;
            }
        }
    }
}

MpResult FaultNodeModule::FaultHandleInfosCollect(const std::string& faultNodeId,
                                                  std::vector<BorrowGroupResult>& borrowGroups,
                                                  std::vector<ClusterSnapshotItem>& baseSnapshot,
                                                  std::string& nodeinfos)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleInfosCollect] Faulthandle parallel collect infos start.";
    // 1. 获取账本并分组
    std::vector<BorrowRecord> borrowRecords;
    MpResult res = GetBorrowNodeInfo(faultNodeId, borrowRecords);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=COLLECT, nodeId=" << faultNodeId
            << ", err=" << MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR << ", reason=get_borrow_node_info_fail.";
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    if (borrowRecords.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=COLLECT, nodeId=" << faultNodeId
            << ", err=" << MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR << ", reason=empty_borrow_records.";
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    // 初始化块大小（根据故障节点配置）
    SetBlockSizeKB(borrowRecords[0].borrowNode);

    borrowGroups = GroupBorrowRecordsByNuma(borrowRecords);
    if (borrowGroups.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=COLLECT, nodeId=" << faultNodeId
            << ", err=" << MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR << ", reason=empty_group_borrow_records.";
        return MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    }
    std::set<std::string> nodeIds;
    for (auto& bg : borrowGroups) {
        nodeIds.insert(bg.borrowNodeId);
    }
    for (auto& nodeId : nodeIds) {
        nodeinfos += nodeId;
        nodeinfos += ",";
    }
    if (!nodeinfos.empty()) {
        nodeinfos.pop_back();
    }
    auto finalError = MEM_POOLING_FAULT_RESOURCE_COLLECT_ERROR;
    // 2. 采集虚机信息，并剔除采集失败的组
    for (auto it = borrowGroups.begin(); it != borrowGroups.end();) {
        std::vector<FaultNumaVmInfo> vmInfos;
        auto ret = GetVmOccupancyForGroup(it->borrowNodeId, it->remoteNumaId, vmInfos);
        if (ret != MEM_POOLING_OK) {
            // 采集失败，删除当前组；日志需用删除前的组信息，否则会打印下一个组的身份
            auto failedBorrowNodeId = it->borrowNodeId;
            auto failedRemoteNumaId = it->remoteNumaId;
            it = borrowGroups.erase(it); // iterator指向下一个
            finalError = get_higher_priority_error(finalError, ret);
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager][FaultLentNode][BorrowOutFaultDegraded] phase=COLLECT, Failed to get VM info for "
                   "(borrowNodeId="
                << failedBorrowNodeId << ", faultNuma=" << failedRemoteNumaId << "), err=" << ret
                << ", remove this group.";

            continue;
        }
        it->vmInfos = std::move(vmInfos);
        it->totalUsedSize = 0;
        for (const auto& vmInfo : it->vmInfos) {
            it->totalUsedSize += vmInfo.remoteNumaUsedMem;
        }
        ++it;
    }

    // 如果所有组都被剔除，则无需继续
    if (borrowGroups.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=COLLECT, No valid borrow groups after VM info "
               "collection, nodeId="
            << faultNodeId << ", err=" << finalError << ", reason=all_groups_removed, BorrowNodeIds=[" << nodeinfos
            << "].";
        return finalError;
    }

    RebuildBorrowGroup(borrowGroups);

    // 3. 获取基础集群快照（失败时静默清空,降级继续）
    res = GetBaseClusterSnapshot(faultNodeId, baseSnapshot);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultDegraded] phase=COLLECT, GetBaseClusterSnapshot failed "
               "(degraded), nodeId="
            << faultNodeId << ", err=" << res << ", reason=base_cluster_snapshot_failed.";
        baseSnapshot.clear();
    }

    // 打印采集结果
    PrintCollectedInfos(borrowGroups, baseSnapshot);
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::SendNumaLevelExecuteRpc(std::string& nodeId, BorrowGroupResult& group, MpResult& outResult)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager] Master to invoke the slave SendNumaLevelExecuteRpc, node=" << nodeId << ".";
    UbseComEndpoint endpoint = {
        .moduleId = MP_MODULE_CODE, .serviceId = message::OPCODE_NUMA_LEVEL_EXECUTE, .address = nodeId};
    RmrsOutStream builder;
    builder << group; // 直接序列化整个 BorrowGroupResult
    UbseByteBuffer reqData = {
        .data = builder.GetBufferPointer(), .len = builder.GetSize(), .freeFunc = [](uint8_t* data) {
            delete[] data;
        }};
    MpResult ret = MEM_POOLING_ERROR;
    uint32_t rpcRet = UbseRpcSend(endpoint, reqData, &ret, NumaLevelExecuteResHandler);
    if (rpcRet != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "SendNumaLevelExecuteRpc RPC send failed, ret=" << rpcRet;
        return MEM_POOLING_ERROR;
    }
    outResult = ret;
    return MEM_POOLING_OK;
}

void NumaLevelExecuteResHandler(void* ctx, const UbseByteBuffer& respData, uint32_t resCode)
{
    if (ctx == nullptr || respData.data == nullptr || respData.len == 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] NumaLevelExecuteResHandler invalid param.";
        return;
    }
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel] resCode=" << resCode << ".";
    MpResult* result = static_cast<MpResult*>(ctx);
    // 优先读 payload 中回填的具体错误码;仅当 payload 无效时 fallback 到 resCode
    if (respData.len == sizeof(MpResult)) {
        *result = *reinterpret_cast<const MpResult*>(respData.data);
        return;
    }
    if (resCode != MEM_POOLING_OK) {
        *result = MEM_POOLING_ERROR;
        return;
    }
    UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
        << "NumaLevelExecuteResHandler unexpected resp len=" << respData.len;
    *result = MEM_POOLING_ERROR;
}

MpResult FaultNodeModule::SendBorrowIdExecuteRpc(std::string& nodeId, BorrowGroupResult& group, MpResult& outResult)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][FaultManager] SendBorrowIdExecuteRpc Master to invoke slave node=" << nodeId << ".";

    UbseComEndpoint endpoint = {
        .moduleId = MP_MODULE_CODE, .serviceId = message::OPCODE_BORROW_ID_LEVEL_EXECUTE, .address = nodeId};
    RmrsOutStream builder;
    builder << group;
    UbseByteBuffer reqData = {
        .data = builder.GetBufferPointer(), .len = builder.GetSize(), .freeFunc = [](uint8_t* data) {
            delete[] data;
        }};
    MpResult ret = MEM_POOLING_ERROR;
    uint32_t rpcRet = UbseRpcSend(endpoint, reqData, &ret, BorrowIdLevelExecuteResHandler);
    if (rpcRet != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "SendBorrowIdExecuteRpc RPC send failed, ret=" << rpcRet << ".";
        return MEM_POOLING_ERROR;
    }
    outResult = ret;
    return MEM_POOLING_OK;
}

void BorrowIdLevelExecuteResHandler(void* ctx, const UbseByteBuffer& respData, uint32_t resCode)
{
    if (ctx == nullptr || respData.data == nullptr || respData.len == 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] BorrowIdLevelExecuteResHandler invalid param.";
        return;
    }
    auto* result = static_cast<MpResult*>(ctx);
    // 优先读 payload 中回填的具体错误码;仅当 payload 无效时 fallback 到 resCode
    if (respData.len == sizeof(MpResult)) {
        *result = *reinterpret_cast<const MpResult*>(respData.data);
        return;
    }
    if (resCode != MEM_POOLING_OK) {
        *result = MEM_POOLING_ERROR;
        return;
    }
    UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
        << "BorrowIdLevelExecuteResHandler unexpected resp len=" << respData.len << ".";
    *result = MEM_POOLING_ERROR;
}

MpResult FaultNodeModule::FaultHandleExecuteParallel(std::vector<BorrowGroupResult>& borrowGroups)
{
    if (borrowGroups.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=EXECUTE, nodeId=none, err="
            << MEM_POOLING_FAULT_LACK_REMOTE_MEM_ERROR << ", reason=empty_borrow_groups.";
        return MEM_POOLING_FAULT_LACK_REMOTE_MEM_ERROR;
    }
    std::vector<std::future<std::pair<std::string, MpResult>>> futures;
    // 1. 处理 NUMA 级别决策的组
    for (auto& group : borrowGroups) {
        if (group.strategyType != BorrowStrategyType::NUMA_LEVEL_STRATEGY) {
            continue;
        }

        futures.push_back(std::async(std::launch::async, [this, &group]() -> std::pair<std::string, MpResult> {
            MpResult result;
            MpResult sendRet = SendNumaLevelExecuteRpc(group.borrowNodeId, group, result);
            if (sendRet != MEM_POOLING_OK) {
                return {group.borrowNodeId, MEM_POOLING_FAULT_IPC_ERROR};
            }
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] borrowNodeId=" << group.borrowNodeId << ", faultNuma=" << group.remoteNumaId
                << ",sendRet=" << sendRet << ", result=" << result << ".";
            return {group.borrowNodeId, result};
        }));
    }

    // 2. 处理 BorrowId 级别决策的组
    for (auto& group : borrowGroups) {
        if (group.strategyType != BorrowStrategyType::BORROW_ID_LEVEL_STRATEGY) {
            continue;
        }

        futures.push_back(std::async(std::launch::async, [this, &group]() -> std::pair<std::string, MpResult> {
            MpResult result;
            MpResult sendRet = SendBorrowIdExecuteRpc(group.borrowNodeId, group, result);
            if (sendRet != MEM_POOLING_OK)
                return {group.borrowNodeId, MEM_POOLING_FAULT_IPC_ERROR};
            return {group.borrowNodeId, result};
        }));
    }

    // 3. 等待所有任务完成并统计失败数
    int failCount = 0;
    int successCnt = 0;
    MpResult ret = MEM_POOLING_ERROR;
    for (auto& f : futures) {
        auto res = f.get();
        if (res.second != MEM_POOLING_OK) {
            failCount++;
            ret = get_higher_priority_error(res.second, ret);
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=EXECUTE, nodeId=" << res.first
                << ", err=" << res.second << ".";
        } else {
            successCnt++;
        }
    }
    UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] Parallel execute end, success count=" << successCnt << ", fail count=" << failCount
        << ".";

    if (failCount == 0) {
        return MEM_POOLING_OK;
    }
    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=EXECUTE, nodeId=aggregate, err=" << ret
        << ", failCount=" << failCount << ", successCnt=" << successCnt << ".";
    return ret;
}

MpResult FaultNodeModule::FaultHandleMigrate(uint16_t presentNumaId, uint16_t faultNumaId, std::vector<pid_t>& pids,
                                             uint64_t borrowMemSize)
{
    std::string pidStr{};
    for (auto pid : pids) {
        pidStr += std::to_string(pid) + ",";
    }
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][FaultHandleMigrate] FaultHandleMigrate start, presentNumaId=" << presentNumaId
        << ", faultNumaId=" << faultNumaId << ", borrowMemSize=" << borrowMemSize << ", pids=[" << pidStr << "].";

    // 分配大页
    auto res = FaultMemIdExecute::Instance().EchoHugepages(presentNumaId, borrowMemSize);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][FaultHandleMigrate] Echo Hugepages failed.";
        return MEM_POOLING_FAULT_MIGRATE_ERROR;
    }

    // 远端迁移
    std::string borrowId{};
    res = FaultMemIdExecute::Instance().VmsMigrateOtherRemoteNuma(pids, faultNumaId, presentNumaId, borrowId, false);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][FaultHandleMigrate] VmsMigrateOtherRemoteNuma failed. oldNumaId=" << faultNumaId
            << ", newNumaId=" << presentNumaId << ".";
        // 远端迁移失败，回滚释放此次分配的大页
        FaultMemIdExecute::Instance().RollBackHugepages(presentNumaId, borrowMemSize);
        return MEM_POOLING_FAULT_MIGRATE_ERROR;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][FaultHandleMigrate] FaultHandleMigrate success.";
    return MEM_POOLING_OK;
}

void UpdateBorrowedDecisionBorrowIdLevel(const BorrowGroupResult& group, const BorrowIdLevelDecision& decision,
                                         const MemBorrowExecuteResult& borrowExecuteResult,
                                         BorrowIdLevelBorrowedDecision& borrowedDecision)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][BorrowIdLevelExecute] BorrowIdLevel migrate failed,"
        << "start to update BorrowedDecision. newName=" << borrowExecuteResult.borrowIds[0]
        << ", oldName=" << decision.oldName << ", presentNumaId=" << borrowExecuteResult.presentNumaId[0] << ".";
    borrowedDecision.presentNumaId = borrowExecuteResult.presentNumaId[0];
    borrowedDecision.oldNumaId = group.remoteNumaId;
    borrowedDecision.pids = decision.pids;
    borrowedDecision.borrowSize = decision.lentMemSize;
    borrowedDecision.oldName = decision.oldName;
    borrowedDecision.newName = borrowExecuteResult.borrowIds[0];

    BorrowedDecision bd;
    auto ret = FaultHandleBorrowedDecision::Instance().Query(bd, borrowedDecision.oldNumaId);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] No borrowed decision found for numaId="
            << borrowedDecision.oldNumaId << ".";
        // 该numaId未找到已有的已借用决策
        bd.borrowNodeId = group.borrowNodeId;
        bd.remoteNumaId = group.remoteNumaId;
        bd.isNumaLevel = false;
    }
    // 如果有相同的oldName，则直接进行覆盖替换；否则，添加到borrowIdBorrowedDecisions中
    auto it = std::find_if(bd.borrowIdBorrowedDecisions.begin(), bd.borrowIdBorrowedDecisions.end(),
                           [&borrowedDecision](const BorrowIdLevelBorrowedDecision& tmp) {
                               return tmp.oldName == borrowedDecision.oldName;
                           });
    if (it != bd.borrowIdBorrowedDecisions.end()) {
        *it = borrowedDecision;
    } else {
        bd.borrowIdBorrowedDecisions.push_back(borrowedDecision);
    }

    ret = FaultHandleBorrowedDecision::Instance().Update(borrowedDecision.oldNumaId, bd);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Update borrowed decision failed for numaId="
            << borrowedDecision.oldNumaId << ".";
    }
}

void UpdateBorrowIdBorrowedDecision(const BorrowGroupResult& group, BorrowIdLevelBorrowedDecision& borrowedDecision)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][BorrowIdLevelExecute] BorrowId-Level borrowedDecision do migrate failed,"
        << "start to update BorrowedDecision. newName=" << borrowedDecision.newName
        << ", oldName=" << borrowedDecision.oldName << ", presentNumaId=" << borrowedDecision.presentNumaId << ".";

    BorrowedDecision bd;
    auto ret = FaultHandleBorrowedDecision::Instance().Query(bd, borrowedDecision.oldNumaId);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] No borrowed decision found for numaId="
            << borrowedDecision.oldNumaId << ".";
        // 该numaId未找到已有的已借用决策
        bd.borrowNodeId = group.borrowNodeId;
        bd.remoteNumaId = group.remoteNumaId;
        bd.isNumaLevel = false;
    }
    // 如果有相同的oldName，则直接进行覆盖替换；否则，添加到borrowIdBorrowedDecisions中
    auto it = std::find_if(bd.borrowIdBorrowedDecisions.begin(), bd.borrowIdBorrowedDecisions.end(),
                           [&borrowedDecision](const BorrowIdLevelBorrowedDecision& tmp) {
                               return tmp.oldName == borrowedDecision.oldName;
                           });
    if (it != bd.borrowIdBorrowedDecisions.end()) {
        *it = borrowedDecision;
    } else {
        bd.borrowIdBorrowedDecisions.push_back(borrowedDecision);
    }

    ret = FaultHandleBorrowedDecision::Instance().Update(borrowedDecision.oldNumaId, bd);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Update borrowed decision failed for numaId="
            << borrowedDecision.oldNumaId << ".";
    }
}

void RemoveBorrowedDecisionBorrowIdLevel(BorrowIdLevelBorrowedDecision borrowedDecision)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][BorrowIdLevelExecute] Start to remove borrowId-level borrowed decision for numaId="
        << borrowedDecision.oldNumaId << ", oldName=" << borrowedDecision.oldName << ".";
    BorrowedDecision bd;
    auto ret = FaultHandleBorrowedDecision::Instance().Query(bd, borrowedDecision.oldNumaId);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] No borrowed decision found for numaId="
            << borrowedDecision.oldNumaId << ".";
        return;
    }

    auto it = std::remove_if(bd.borrowIdBorrowedDecisions.begin(), bd.borrowIdBorrowedDecisions.end(),
                             [&borrowedDecision](const BorrowIdLevelBorrowedDecision& tmp) {
                                 return tmp.oldName == borrowedDecision.oldName;
                             });
    if (it == bd.borrowIdBorrowedDecisions.end()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] No borrowed decision found for borrowId="
            << borrowedDecision.oldName << ".";
        return;
    }
    bd.borrowIdBorrowedDecisions.erase(it, bd.borrowIdBorrowedDecisions.end());

    if (bd.borrowIdBorrowedDecisions.empty()) {
        // 删除整个numaId条目
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Remove borrowId-level borrowed decision for numaId="
            << borrowedDecision.oldNumaId << ", oldName=" << borrowedDecision.oldName << ".";
        ret = FaultHandleBorrowedDecision::Instance().Remove(borrowedDecision.oldNumaId);
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Update borrowId-level borrowed decision for numaId="
            << borrowedDecision.oldNumaId << ", oldName=" << borrowedDecision.oldName << ".";
        ret = FaultHandleBorrowedDecision::Instance().Update(borrowedDecision.oldNumaId, bd);
    }

    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Remove borrowId-level borrowed decision failed.";
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][BorrowIdLevelExecute] Remove borrowId-level borrowed decision success.";
}

MpResult FaultNodeModule::BorrowIdLevelExecute(const BorrowGroupResult& group, BorrowIdLevelDecision decision)
{
    // 1 借用新内存
    SrcMemoryBorrowParam srcParam{group.borrowNodeId, static_cast<int16_t>(group.borrowSocketId),
                                  static_cast<int16_t>(decision.borrowNumaId), decision.uid, decision.username};
    MemBorrowExecuteResult borrowExecuteResult;
    std::vector<DestMemoryBorrowParam> destParamList;
    uint16_t destNumaNum = 1;
    std::vector<int> destNumaIdList{decision.lentNumaId};
    std::vector<uint64_t> memSizeList{decision.lentMemSize};
    DestMemoryBorrowParam destMemoryBorrowParam{decision.lentNodeId, decision.lentSocketId, destNumaNum, destNumaIdList,
                                                memSizeList};
    destParamList.push_back(destMemoryBorrowParam);
    MpResult res = MempoolBorrowModule::Instance().MemBorrowExecute(srcParam, destParamList, borrowExecuteResult);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Borrow mem error srcNode=" << group.borrowNodeId
            << ",destNode=" << decision.lentNodeId << ",size=" << decision.lentMemSize << ".";
        return res;
    }

    // 2 分配大页+远端迁移
    res = FaultNodeModule::FaultHandleMigrate(borrowExecuteResult.presentNumaId[0], group.remoteNumaId, decision.pids,
                                              decision.lentMemSize);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] FaultHandleMigrate error oldNumaId=" << group.remoteNumaId
            << ", newNumaId=" << borrowExecuteResult.presentNumaId[0] << ".";
        // 迁移失败，更新以借用但迁移失败的决策到数据库中
        BorrowIdLevelBorrowedDecision borrowedDecision;
        UpdateBorrowedDecisionBorrowIdLevel(group, decision, borrowExecuteResult, borrowedDecision);
        return res;
    }

    // 3 归还旧内存
    res = MemBorrowExecutor::Instance().MemFreeWithOps(decision.oldName, false, true, true);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] MemFreeWithOps error oldName=" << decision.oldName << ".";
        // 归还旧内存失败，登记已借用的新内存，避免新借内存成为无账本资源被重复借用，后续轮次可重试归还
        BorrowIdLevelBorrowedDecision borrowedDecision;
        UpdateBorrowedDecisionBorrowIdLevel(group, decision, borrowExecuteResult, borrowedDecision);
        return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
    }
    // 4 归还成功后更新借用描述符的重定向关系表
    MpResult retBorrId = BorrowIdRedirection::Instance().Update(decision.oldName, borrowExecuteResult.borrowIds[0]);
    if (retBorrId != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecute] Update borrowId redirection failed. oldName="
            << decision.oldName << ", newBorrowId=" << borrowExecuteResult.borrowIds[0] << ".";
    }

    return MEM_POOLING_OK;
}

namespace {
// smap机制：仅当存在smap纳管进程时，Smap MigrateBack才能成功（无纳管进程时迁移回传消息为空直接失败）。
// 拓扑获取或任一NUMA查询失败时保守返回true维持smap迁回路径，避免误直接归还导致数据丢失。
bool HasSmapManagedPidOnAnyRemoteNuma()
{
    std::vector<uint16_t> numaSet;
    if (exportV2::OsHelper::GetNumaSet(numaSet) != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel] Get numa set failed, keep smap migrate back path.";
        return true;
    }
    for (uint16_t numaId : numaSet) {
        bool isLocal = true;
        if (exportV2::OsHelper::IsNumaLocal(numaId, isLocal) != MEM_POOLING_OK) {
            // 单节点属性读取异常按缺失节点跳过，兼容非连续编号（同参考实现）
            continue;
        }
        if (isLocal) {
            continue;
        }
        std::vector<ProcessPayload> processPayloadList;
        if (MpSmapHelper::SmapQueryProcessConfigHelper(numaId, processPayloadList) != MEM_POOLING_OK) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] Query smap managed pids of remoteNumaId=" << numaId
                << " failed, keep smap migrate back path.";
            return true;
        }
        if (!processPayloadList.empty()) {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel] RemoteNumaId=" << numaId << " has " << processPayloadList.size()
                << " smap managed pid(s), keep smap migrate back path.";
            return true;
        }
    }
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel] No smap managed pid on remote numa(s), direct return without smap migrate back.";
    return false;
}
} // namespace

void BorrowIdLevelReturnDirectly(const BorrowIdLevelDecision& decision, int errCount)
{
    if (decision.isReturnDirectly && errCount > 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[BorrowIdLevelExecuteHandler] borrowId=" << decision.oldName
            << " should be directly return, but there are execute error before.";
        return;
    }

    if (decision.isReturnDirectly && errCount == 0) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[BorrowIdLevelExecuteHandler] Start to free directly for oldName=" << decision.oldName << ".";
        // 归还前判定本机所有远端numa是否存在smap纳管pid，决定归还路径是否走smap迁回
        bool smapBack = HasSmapManagedPidOnAnyRemoteNuma();
        auto ret = MemBorrowExecutor::Instance().MemFreeWithOps(decision.oldName, false, smapBack, true);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[BorrowIdLevelExecuteHandler] direct free oldName=" << decision.oldName << "failed. ret=" << ret
                << ".";
        } else {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[BorrowIdLevelExecuteHandler] direct free oldName=" << decision.oldName << " success.";
        }
        return;
    }
}

MpResult FaultNodeModule::BorrowIdLevelBorrowedExecute(const BorrowGroupResult& group,
                                                       BorrowIdLevelBorrowedDecision borrowedDecision)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][BorrowIdLevelBorrowedExecute] BorrowIdLevel-BorrowedDecisionExecute start, oldName="
        << borrowedDecision.oldName << ", newName=" << borrowedDecision.newName << ".";
    // 1 分配大页+远端迁移
    auto res = FaultNodeModule::FaultHandleMigrate(borrowedDecision.presentNumaId, borrowedDecision.oldNumaId,
                                                   borrowedDecision.pids, borrowedDecision.borrowSize);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelBorrowedExecute] FaultHandleMigrate error oldNumaId="
            << borrowedDecision.oldNumaId << ", newNumaId=" << borrowedDecision.presentNumaId << ".";
        // 更新BorrowedDecisionMap
        UpdateBorrowIdBorrowedDecision(group, borrowedDecision);
        return MEM_POOLING_ERROR;
    }

    // 2 归还旧内存
    res = MemBorrowExecutor::Instance().MemFreeWithOps(borrowedDecision.oldName, false, true, true);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelBorrowedExecute] MemFreeWithOps error oldName="
            << borrowedDecision.oldName << ".";
        // 归还失败时保留该borrowedDecision，待下一轮重试归还，避免旧内存失去回收路径
        return MEM_POOLING_ERROR;
    }
    // 3 归还成功后移除该borrowedDecision
    RemoveBorrowedDecisionBorrowIdLevel(borrowedDecision);

    // 4 归还成功后更新借用描述符的重定向关系表
    MpResult retBorrId = BorrowIdRedirection::Instance().Update(borrowedDecision.oldName, borrowedDecision.newName);
    if (retBorrId != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelBorrowedExecute] Update borrowId redirection failed. oldName="
            << borrowedDecision.oldName << ", newName=" << borrowedDecision.newName << ".";
    }

    return MEM_POOLING_OK;
}

uint32_t BorrowIdLevelExecuteHandler(const UbseByteBuffer& req, UbseByteBuffer& resp)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultNode] BorrowIdLevelExecuteHandler start.";
    BorrowGroupResult group;
    RmrsInStream inBuilder(req.data, req.len);
    inBuilder >> group;
    int errCount = 0;
    MpResult ret;
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[BorrowIdLevelExecuteHandler] BorrowNodeId=" << group.borrowNodeId << ", faultNumaId=" << group.remoteNumaId
        << " start to execute fault handle";
    MpResult finalRet = MEM_POOLING_ERROR;
    for (const auto& decision : group.borrowIdDecisions) {
        if (decision.isReturnDirectly) {
            BorrowIdLevelReturnDirectly(decision, errCount);
            continue;
        }

        if (decision.isBorrowed) {
            ret = FaultNodeModule::Instance().BorrowIdLevelBorrowedExecute(group, decision.borrowedDecision);
            if (ret != MEM_POOLING_OK) {
                UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[BorrowIdLevelExecuteHandler] BorrowIdLevelBorrowedExecute failed. ret=" << ret << ".";
                errCount++;
                finalRet = get_higher_priority_error(finalRet, ret);
            }
            continue;
        }

        // 决策结果执行函数（不包括直接归还决策）
        ret = FaultNodeModule::Instance().BorrowIdLevelExecute(group, decision);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[BorrowIdLevelExecuteHandler] BorrowIdLevelExecute failed. ret=" << ret << ".";
            errCount++;
            finalRet = get_higher_priority_error(finalRet, ret);
        }
        continue;
    }

    resp.freeFunc = [](uint8_t* data) {
        delete[] data;
    };

    if (errCount > 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecuteHandler] BorrowIdLevelExecute errCount=" << errCount << ".";
        resp.len = sizeof(MpResult);
    } else {
        resp.len = sizeof(MpResult);
        finalRet = MEM_POOLING_OK;
    }

    resp.data = new (std::nothrow) uint8_t[resp.len];
    if (resp.data == nullptr) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][BorrowIdLevelExecuteHandler] NumaLevelExecute failed, size=" << resp.len << ".";
        return MEM_POOLING_ERROR;
    }
    *reinterpret_cast<MpResult*>(resp.data) = finalRet;

    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::NumaLevelMemBorrow(const BorrowGroupResult& group, NumaLevelDecision decision,
                                             std::map<std::string, MemBorrowExecuteResult>& tmpRedirectionMap,
                                             uint16_t& presentNumaId)
{
    // numa级别借用，新借内存的账本数量和Size应和group中的records记录保持一致
    SrcMemoryBorrowParam srcParam{group.borrowNodeId, static_cast<int16_t>(group.borrowSocketId),
                                  static_cast<int16_t>(decision.borrowNumaId), decision.uid, decision.username};
    MemBorrowExecuteResult borrowExecuteResult;
    uint64_t totalBorrowSize{};

    // 遍历group中的records，对每个record进行相应的borrow
    for (auto& record : group.records) {
        std::vector<DestMemoryBorrowParam> destParamList;
        uint16_t destNumaNum = 1;
        std::vector<int> destNumaIdList{decision.lentNumaId};
        std::vector<uint64_t> memSizeList{record.size}; // 对应该账本的size
        DestMemoryBorrowParam destMemoryBorrowParam{decision.lentNodeId, decision.lentSocketId, destNumaNum,
                                                    destNumaIdList, memSizeList};
        destParamList.push_back(destMemoryBorrowParam);
        MpResult res = MempoolBorrowModule::Instance().MemBorrowExecute(srcParam, destParamList, borrowExecuteResult);
        if (res != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] FaultHandle borrow mem for oldName=" << record.name
                << " failed, destNode=" << decision.lentNodeId << ", borrowSize=" << record.size << ".";
            // 如果有任何一个borrow失败，需要回滚归还之前的所有借用的内存
            for (auto& [_, borrowExecuteResult] : tmpRedirectionMap) {
                // 第三个参数smapBack设为false，不走smapMigrateBack逻辑，直接进行ubse归还
                auto newName = borrowExecuteResult.borrowIds[0];
                auto ret = MemBorrowExecutor::Instance().MemFreeWithOps(newName, false, false, true);
                if (ret != MEM_POOLING_OK) {
                    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                        << "[FaultHandleParallel][NumaIdLevelExecute]"
                        << "Cause MemBorrow failed, need to free borrowRecord which successed before, borrowId="
                        << newName << ", but memFree failed, ret=" << ret << ".";
                }
            }
            return res;
        }
        tmpRedirectionMap[record.name] = borrowExecuteResult;
        presentNumaId = borrowExecuteResult.presentNumaId[0]; // 所有record的presentNumaId相同
        totalBorrowSize += record.size;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][NumaIdLevelExecute]"
        << "NumaLevelMemBorrow success, presentNumaId=" << presentNumaId << ", borrowCount=" << tmpRedirectionMap.size()
        << ", totalBorrowSize=" << totalBorrowSize << ".";
    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::NumaLevelBorrowedExecute(const BorrowGroupResult& group, NumaLevelBorrowedDecision decision)
{
    // 1 对于已借用过的决策直接执行远端迁移
    auto res = FaultHandleMigrate(decision.presentNumaId, decision.oldNumaId, decision.pids, decision.totalBorrowSize);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][NumaIdLevelExecute] FaultHandleMigrate failed. oldNumaId=" << decision.oldNumaId
            << ", newNumaId=" << decision.presentNumaId << ".";
        BorrowedDecision borrowedDecision = {.borrowNodeId = group.borrowNodeId,
                                             .remoteNumaId = group.remoteNumaId,
                                             .isNumaLevel = true,
                                             .numaBorrowedDecision = decision};
        // 更新BorrowedDecisionMap
        FaultHandleBorrowedDecision::Instance().Update(decision.oldNumaId, borrowedDecision);
        return MEM_POOLING_FAULT_MIGRATE_ERROR;
    }

    // 2 迁移完成，移除BorrowedDecisionMap
    res = FaultHandleBorrowedDecision::Instance().Remove(decision.oldNumaId);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][NumaIdLevelExecute] FaultHandleBorrowedDecision Remove failed. oldNumaId="
            << decision.oldNumaId << ".";
    }

    // 3 归还旧内存
    for (auto [oldName, newName] : decision.borrowResultMap) {
        res = MemBorrowExecutor::Instance().MemFreeWithOps(oldName, false, true, true);
        if (res != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] MemFreeWithOps error oldName " << oldName << ".";
            return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
        }
        // 4 归还成功后，更新borrowId重定向关系
        MpResult retBorrId = BorrowIdRedirection::Instance().Update(oldName, newName);
        if (retBorrId != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] Update borrowId redirection failed. oldName=" << oldName
                << ", newBorrowId=" << newName << ".";
        }
    }

    return MEM_POOLING_OK;
}

void fillBorrowedDecisionNumaLevel(const BorrowGroupResult& group, const NumaLevelDecision& decision,
                                   std::map<std::string, MemBorrowExecuteResult>& tmpRedirectionMap,
                                   BorrowedDecision& borrowedDecision)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][NumaIdLevelExecute] NumaLevel migrate failed, start to update borrowedDecision.";
    borrowedDecision.borrowNodeId = group.borrowNodeId;
    borrowedDecision.remoteNumaId = group.remoteNumaId;
    borrowedDecision.isNumaLevel = true;
    borrowedDecision.numaBorrowedDecision.oldNumaId = group.remoteNumaId;
    borrowedDecision.numaBorrowedDecision.pids = decision.pids;
    borrowedDecision.numaBorrowedDecision.totalBorrowSize = decision.lentMemSize;
    for (const auto& [oldName, borrowExecuteResult] : tmpRedirectionMap) {
        borrowedDecision.numaBorrowedDecision.borrowResultMap[oldName] = borrowExecuteResult.borrowIds[0];
        // presentNumaId在一个numa级别的决策中都是相同的
        borrowedDecision.numaBorrowedDecision.presentNumaId = borrowExecuteResult.presentNumaId[0];
    }
}

MpResult FaultNodeModule::NumaLevelExecuteNormal(const BorrowGroupResult& group, NumaLevelDecision decision,
                                                 std::map<std::string, MemBorrowExecuteResult>& tmpRedirectionMap)
{
    // 1 借用新内存
    uint16_t presentNumaId{};
    std::string borrowId{};
    MpResult res = NumaLevelMemBorrow(group, decision, tmpRedirectionMap, presentNumaId);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][NumaIdLevelExecute] NumaLevelMemBorrow failed.";
        return res;
    }

    // 2 远端迁移
    res = FaultHandleMigrate(presentNumaId, group.remoteNumaId, decision.pids, decision.lentMemSize);
    if (res != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][NumaIdLevelExecute] FaultHandleMigrate failed. oldNumaId=" << group.remoteNumaId
            << ", newNumaId=" << presentNumaId << ".";
        // 迁移失败，更新borrowedDecisionMap
        BorrowedDecision borrowedDecision;
        fillBorrowedDecisionNumaLevel(group, decision, tmpRedirectionMap, borrowedDecision);
        auto ret = FaultHandleBorrowedDecision::Instance().Update(group.remoteNumaId, borrowedDecision);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] FaultHandleBorrowedDecision Update failed. oldNumaId="
                << group.remoteNumaId << ".";
        }
        return res;
    }

    // 3 归还旧内存
    for (auto [oldName, borrowResult] : tmpRedirectionMap) {
        res = MemBorrowExecutor::Instance().MemFreeWithOps(oldName, false, true, true);
        if (res != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] MemFreeWithOps error oldName " << oldName << ".";
            return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
        }

        MpResult retBorrId = BorrowIdRedirection::Instance().Update(oldName, borrowResult.borrowIds[0]);
        if (retBorrId != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] Update borrowId redirection failed. oldName=" << oldName
                << ", newBorrowId=" << borrowResult.borrowIds[0] << ".";
        }
    }

    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::NumaLevelExecute(const BorrowGroupResult& group, NumaLevelDecision decision,
                                           std::map<std::string, MemBorrowExecuteResult>& tmpRedirectionMap)
{
    if (decision.isReturnDirectly) {
        // 直接归还旧内存
        // 归还前查询本机所有远端numa是否存在smap纳管pid：存在则走smap迁回路径，全部无纳管则直接归还
        bool smapBack = HasSmapManagedPidOnAnyRemoteNuma();
        for (auto oldName : decision.oldNames) {
            auto ret = MemBorrowExecutor::Instance().MemFreeWithOps(oldName, false, smapBack, true);
            if (ret != MEM_POOLING_OK) {
                UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[FaultHandleParallel][NumaIdLevelExecute] MemFreeWithOps error oldName " << oldName << ".";
                return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
            }
        }
        return MEM_POOLING_OK;
    }

    if (decision.isBorrowed) {
        auto ret = NumaLevelBorrowedExecute(group, decision.borrowedDecision);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[FaultHandleParallel][NumaIdLevelExecute] NumaLevelBorrowedExecute failed.";
            return ret;
        }
        return MEM_POOLING_OK;
    }

    auto ret = NumaLevelExecuteNormal(group, decision, tmpRedirectionMap);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultHandleParallel][NumaIdLevelExecute] NumaLevelDoExecute failed.";
        return ret;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultHandleParallel][NumaIdLevelExecute] NumaLevelExecute success, borrowNodeId=" << group.borrowNodeId
        << ", faultNumaId=" << group.remoteNumaId << ".";
    return MEM_POOLING_OK;
}

uint32_t NumaLevelExecuteHandler(const UbseByteBuffer& req, UbseByteBuffer& resp)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[FaultHandleParallel] NumaLevelExecuteHandler start.";
    if (req.data == nullptr || req.len == 0) {
        LOG_ERROR << "[NumaLevelExecuteHandler] req.data is null or len is 0.";
        return MEM_POOLING_ERROR;
    }
    BorrowGroupResult group;
    RmrsInStream inBuilder(req.data, req.len);
    inBuilder >> group;
    MpResult res;
    NumaLevelDecision numaDecision = group.numaDecision;
    resp.freeFunc = [](uint8_t* data) {
        delete[] data;
    };
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[NumaLevelExecuteHandler] BorrowNodeId=" << group.borrowNodeId << ", faultNumaId=" << group.remoteNumaId
        << " start to execute fault handle";
    std::map<std::string, MemBorrowExecuteResult> tmpRedirectionMap; // key为oldName，value为该oldName对应的新借用记录
    res = FaultNodeModule::Instance().NumaLevelExecute(group, numaDecision, tmpRedirectionMap);
    if (MEM_POOLING_OK != res) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[NumaLevelExecuteHandler] Recv NumaLevelExecute res=" << res << ".";
        resp.len = sizeof(MpResult);
    } else {
        resp.len = sizeof(MpResult);
    }

    resp.data = new (std::nothrow) uint8_t[resp.len];
    if (resp.data == nullptr) {
        LOG_ERROR << "[NumaLevelExecuteHandler] NumaLevelExecute failed, size=" << resp.len << ".";
        return MEM_POOLING_ERROR;
    }
    *reinterpret_cast<MpResult*>(resp.data) = res;

    return MEM_POOLING_OK;
}

MpResult FaultNodeModule::ProcessBorrowOutNodeFaultParallel(const std::string nodeId, bool forceDeleteMem)
{
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager][FaultLentNode] Borrow out faulthandle parallel start, nodeId=" << nodeId << ".";
    // 采集阶段
    std::vector<BorrowGroupResult> borrowGroups;
    std::vector<ClusterSnapshotItem> clusterInfos;
    std::string nodeinfos;
    auto ret = FaultHandleInfosCollect(nodeId, borrowGroups, clusterInfos, nodeinfos);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=COLLECT, nodeId=" << nodeId << ", err=" << ret
            << ".";
        return ret;
    }
    // 故障处理借用决策阶段
    auto strategyRes = FaultHandleBorrowStrategy(borrowGroups, clusterInfos);
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager][FaultLentNode] FaultHandle strategyRet=" << strategyRes << ".";

    // 故障处理执行阶段
    auto execRes = FaultHandleExecuteParallel(borrowGroups);
    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[FaultManager][FaultLentNode] FaultHandle execute ret=" << execRes << ".";

    if (strategyRes != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=STRATEGY, nodeId=" << nodeId
            << ", err=" << strategyRes << ", BorrowNodeIds=[" << nodeinfos << "].";
        return strategyRes;
    }

    if (execRes != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[FaultManager][FaultLentNode][BorrowOutFaultFail] phase=EXECUTE, nodeId=" << nodeId
            << ", err=" << execRes << ".";
    }

    return execRes;
}

void GetPidListAndHugePageMemSize(const NumaReplaceReturnMsg& rpcMsg, std::vector<pid_t>& destPidList,
                                  uint64_t& hugePageMemSize)
{
    if (!FaultNodeModule::Instance().QueryNumaAllPid(rpcMsg.destNid, destPidList)) {
        LOG_INFO << "[FaultManager] [FaultLentNode] DestPidList may empty.";
    }
    // 计算需要分配大页的内存大小，单位b
    for (size_t i = 0; i < rpcMsg.BorrowExecuteParamVec.size(); i++) {
        hugePageMemSize += rpcMsg.BorrowExecuteParamVec[i].memSize;
    }
    hugePageMemSize = hugePageMemSize * KB_1024;
    LOG_DEBUG << "[FaultManager] [FaultLentNode] Param hugePageMemSize=" << hugePageMemSize
              << "B, srcNid=" << rpcMsg.srcNid << ", destNid=" << rpcMsg.destNid << ".";
}

} // namespace mempooling