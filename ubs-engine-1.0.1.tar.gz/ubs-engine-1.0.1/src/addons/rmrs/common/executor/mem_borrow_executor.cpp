/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 
 * UBS RMRS is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include "mem_borrow_executor.h"

#include <atomic>
#include <cerrno>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <thread>

#include "ubse_election.h"
#include "ubse_error.h"
#include "ubse_logger.h"
#include "ubse_mem_controller.h"
#include "ubse_node_controller.h"
#include "mem_manager.h"
#include "mempooling_return_module.h"
#include "mp_configuration.h"
#include "mp_smap_controller.h"
#include "mp_string_util.h"
#include "over_commit_fault_memid_module.h"
#include "process_mem_pid_manager_def.h"

namespace mempooling {
using namespace ubse::log;
using namespace ubse::com;
using namespace rmrs::serialize;
using namespace mempooling::smap;
using namespace ubse::mem::controller;
constexpr int MAX_REDIRECT_COUNT = 64; // borrowid重定向最大次数，防止死循环
constexpr int UUID_BYTE_SIZE = 16;
constexpr int RANDOM_BYTE_MIN = 0;
constexpr int RANDOM_BYTE_MAX = 255;
constexpr auto RESOURCE_KIND = "MEM";
constexpr int WIDTH = 2;

MpResult MemBorrowExecutor::PrepareMemNumaCreateParams(const std::string attachNode,
                                                       const RackCreateResourceWaterBorrowAttr& attr,
                                                       UbseMemBorrower& borrower,
                                                       std::vector<UbseMemNumaLender>& lenders,
                                                       uint8_t usrInfo[ubse::mem::controller::UBSE_MAX_USR_INFO_LEN])
{
    if (attr.waterMallocAttr.lenderLocs.size() != attr.waterMallocAttr.lenderSizes.size()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] lenderLocs and lenderSizes size mismatch: "
            << attr.waterMallocAttr.lenderLocs.size() << " vs " << attr.waterMallocAttr.lenderSizes.size();
        return MEM_POOLING_ERROR;
    }

    // ubse: 借入方
    borrower.nodeId = attachNode;
    if (MpConfiguration::GetInstance().GetMustSamePlane()) {
        borrower.affinitySocketId = attr.waterMallocAttr.srcSocket;
    }
    borrower.uid = attr.waterMallocAttr.uid;
    borrower.username = attr.waterMallocAttr.username;
    // ubse: 借出方

    MEM_POOLING_RES ret = MEM_POOLING_OK;
    for (size_t i = 0; i < attr.waterMallocAttr.lenderLocs.size(); i++) {
        UbseMemNumaLender lender;
        lender.size = attr.waterMallocAttr.lenderSizes[i];
        lender.numaId = attr.waterMallocAttr.lenderLocs[i].numaId;
        ret = MpStringUtil::SafeStoul(attr.waterMallocAttr.lenderLocs[i].nodeId, lender.slotId);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemBorrow][MemBorrowExecute] SafeStoul failed, slotId="
                << attr.waterMallocAttr.lenderLocs[i].nodeId << " , ret=" << ret << ".";
            return MEM_POOLING_ERROR;
        }
        lender.socketId = attr.waterMallocAttr.lenderLocs[i].socketId;
        (void)lenders.emplace_back(lender);
    }

    errno_t err = memcpy_s(usrInfo, ubse::mem::controller::UBSE_MAX_USR_INFO_LEN, &attr.waterMallocAttr.srcNuma,
                           sizeof(attr.waterMallocAttr.srcNuma));
    if (err != 0) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] Memcpy_s failed, error_code=" << err << ".";
        return MEM_POOLING_ERROR;
    }

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::MemBorrow(const std::string& attachNode, const RackCreateResourceWaterBorrowAttr& attr,
                                      std::string& name, int16_t& presentNumaId, bool isBorrowIdPersistence)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemBorrow][MemBorrowExecute] MemBorrowExecutor starts to borrow memory.";

    if (GenerateUniqueId(attachNode, name) != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] Generate unique name failed, attachNode=" << attachNode << ".";
        return MEM_POOLING_FAULT_BORROW_MEM_ERROR;
    }

    UbseMemBorrower borrower;
    std::vector<UbseMemNumaLender> lenders;
    uint8_t usrInfo[ubse::mem::controller::UBSE_MAX_USR_INFO_LEN];

    if (PrepareMemNumaCreateParams(attachNode, attr, borrower, lenders, usrInfo) != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] Prepare params of MemNumaCreate interface failed, attachNode="
            << attachNode << ".";
        return MEM_POOLING_FAULT_BORROW_MEM_ERROR;
    }

    if (isBorrowIdPersistence) {
        MpResult retBorrowIdsCompleted = BorrowIdsCompleted::Instance().Update(name);
        if (retBorrowIdsCompleted != MEM_POOLING_OK) {
            // 可靠性保障，如果失败，不影响主功能
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemBorrow][MemBorrowExecute] UpdateBorrowIdCompleted failed, borrow_id=" << name << ".";
        }
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemBorrow][MemBorrowExecute] Start calling ubse interface "
                                                        "for memory borrowing.";

    // 调用ubse借用接口
    UbseMemNumaDesc ubseMemNumaDesc;
    auto start = std::chrono::steady_clock::now();
    UbseResult errCode = UbseMemNumaCreateWithLender(name, borrower, lenders, usrInfo, ubseMemNumaDesc);
    auto end = std::chrono::steady_clock::now();
    if (errCode != UBSE_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] Borrow memory by memfabric failed, attachNode=" << attachNode
            << " errCode=" << errCode << ".";
        return MEM_POOLING_FAULT_BORROW_MEM_ERROR;
    }
    // 处理结果
    presentNumaId = ubseMemNumaDesc.numaId;

    if (presentNumaId <= 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrow][MemBorrowExecute] Borrow memory by memfabric success, but presentNumaId=" << presentNumaId
            << " is invalid, which is less than or equal to 0.";
        return MEM_POOLING_FAULT_BORROW_MEM_ERROR;
    }
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemBorrow][MemBorrowExecute] Execution time=" << duration.count()
        << " microseconds, borrowMemSize=" << attr.size << " Byte.";

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemBorrow][MemBorrowExecute] MemBorrowExecutor borrows memory success, borrow_id=" << name << ".";

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::MemFree(const std::string& name)
{
    return MemFreeWithOps(name, false, false);
}

MpResult MemBorrowExecutor::RemoveBorrowIdRedirectionRecursively(const std::string& name)
{
    MpResult retDirect;

    std::string redirectNameKey = name;
    std::string redirectNameVal = name;
    do {
        redirectNameKey = redirectNameVal;
        redirectNameVal.clear();
        retDirect = BorrowIdRedirection::Instance().Query(redirectNameKey, redirectNameVal);
        if (retDirect != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Get redirection of borrow_id=" << name << " failed.";
            return retDirect;
        }
        if (redirectNameVal.empty()) {
            break; // 如果redirectNameVal为空，说明已经没有重定向关系，不需要再删除
        }
        retDirect = BorrowIdRedirection::Instance().Remove(redirectNameKey);
        if (retDirect != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Remove redirection of borrow_id=" << name << " failed.";
            return retDirect;
        }
    } while (!redirectNameVal.empty());

    return MEM_POOLING_OK;
}

static __always_inline void GenerateSmapTaskId(uint64_t& taskId)
{
    struct timespec ts {
    };
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Failed to get time errno=" << errno;
        return;
    }
    taskId = static_cast<uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<uint64_t>(ts.tv_nsec);
}

MpResult MemBorrowExecutor::GetBorrowRecordForSmapParams(const std::string& name, BorrowRecord& record, bool isFault)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Start to get borrow record, borrow_id=" << name << ", isFault=" << isFault;
    int maxRetry = 6;
    int curRetry = maxRetry;
    while (curRetry--) {
        std::vector<BorrowRecord> borrowRecords;
        auto ret = BorrowRecordHelper::Instance().CollectBorrowRecordsAll(borrowRecords, isFault);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] CollectBorrowRecords failed.";
        } else {
            for (auto& recordTmp : borrowRecords) {
                if (recordTmp.name == name && recordTmp.borrowMemId.size() > 0) {
                    record = recordTmp;
                    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
                        << "[MemFree][MemFreeExecute] Find borrow_id=" << name << " in ubse debt.";
                    return MEM_POOLING_OK;
                }
            }
        }

        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Borrow_id=" << name << " not found in current round, wait 1s to retry...";
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] Not found borrow_id=" << name
                                                      << "in ubse debt after retry " << maxRetry << " times.";

    return MEM_POOLING_ERROR;
}

MpResult MemBorrowExecutor::GenerateSmapParams(const std::string& name, std::vector<MigrateBackMsg>& migrateBackMsgList,
                                               EnableNodeMsg& enableMsg, std::string& importNodeId, bool isFault)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Begin to generate smap migrate back params list, borrow_id=" << name << ".";

    bool isContainerScene = (MpConfiguration::GetInstance().GetSceneType() == MpSceneType::CONTAINER_SCENE);

    BorrowRecord record;
    MpResult ret = GetBorrowRecordForSmapParams(name, record, isFault);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] GetBorrowRecord failed.";
        return ret;
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Find borrow_id=" << name << ", borrowMemId.size=" << record.borrowMemId.size()
        << ", start to split.";

    // 计算目标 destNid（容器场景不同）
    int destNid = -1;
    if (isContainerScene) {
        destNid = record.borrowLocalNuma;
    }

    importNodeId = record.borrowNode;
    enableMsg.nid = record.borrowRemoteNuma;
    enableMsg.enable = SMAP_ENABLE_NUMA;

    // 将 borrowMemId 拆分成多个 chunk，每个最多 MAX_NR_MIGBACK_MP 个
    const size_t chunkSize = MAX_NR_MIGBACK_MP;
    const auto& memIds = record.borrowMemId;
    size_t totalCount = memIds.size();
    size_t offset = 0;

    while (offset < totalCount) {
        size_t curCount = std::min(chunkSize, totalCount - offset);
        MigrateBackMsg msg;
        msg.count = static_cast<int>(curCount);
        // 生成新的 taskID
        uint64_t taskId{};
        GenerateSmapTaskId(taskId);
        msg.taskID = taskId;
        for (size_t i = 0; i < curCount; ++i) {
            msg.payload[i].memid = memIds[offset + i];
            msg.payload[i].srcNid = record.borrowRemoteNuma;
            msg.payload[i].destNid = destNid;
        }

        // 打印日志
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Chunk offset=" << offset << ", srcNid=" << msg.payload[0].srcNid
            << ", dstNid=" << msg.payload[0].destNid << ", first memid=" << msg.payload[0].memid
            << ", last memid=" << msg.payload[curCount - 1].memid;

        migrateBackMsgList.push_back(std::move(msg));
        offset += curCount;
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Generated " << migrateBackMsgList.size()
        << " smap migrate back msg for borrow_id=" << name << ".";

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::GenerateSmapParamsForProcessMem(const UbseNumaMemoryDebtInfo& matchedDebtInfo,
                                                            std::vector<MigrateBackMsg>& migrateBackMsgs,
                                                            EnableNodeMsg& enableMsg)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Begin to generate smap migrate back params, borrow_id=" << matchedDebtInfo.name
        << ".";

    int srcNuma = -1;
    MpResult ret = FindCurrentDebtInfoAndSrcNuma(matchedDebtInfo, srcNuma);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] FindCurrentDebtInfoAndSrcNuma failed for borrow_id=" << matchedDebtInfo.name
            << ".";
        return ret;
    }

    int destNid = srcNuma;
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Found borrow_id=" << matchedDebtInfo.name << ", destNid=" << destNid
        << ", remoteNumaId=" << matchedDebtInfo.remoteNumaId
        << ", borrowMemId.size()=" << matchedDebtInfo.borrowMemId.size()
        << ", start to generate smap migrate back params.";

    for (size_t j = 0; j < matchedDebtInfo.borrowMemId.size(); j += MAX_NR_MIGBACK_MP) {
        MigrateBackMsg migrateBackMsg;
        size_t batchEnd = std::min(j + MAX_NR_MIGBACK_MP, matchedDebtInfo.borrowMemId.size());
        size_t batchSize = batchEnd - j;
        for (size_t i = 0; i < batchSize; i++) {
            migrateBackMsg.payload[i].memid = matchedDebtInfo.borrowMemId[j + i];
            migrateBackMsg.payload[i].srcNid = matchedDebtInfo.remoteNumaId;
            migrateBackMsg.payload[i].destNid = destNid;
        }
        migrateBackMsg.count = static_cast<int>(batchSize);
        uint64_t taskId{};
        GenerateSmapTaskId(taskId);
        migrateBackMsg.taskID = taskId;
        for (int i = 0; i < migrateBackMsg.count; i++) {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Index=" << i << ", srcNid=" << migrateBackMsg.payload[i].srcNid
                << ", dstNid=" << migrateBackMsg.payload[i].destNid << ", memid=" << migrateBackMsg.payload[i].memid;
        }
        migrateBackMsgs.push_back(migrateBackMsg);
    }

    enableMsg.nid = matchedDebtInfo.remoteNumaId;
    enableMsg.enable = SMAP_ENABLE_NUMA;

    return MEM_POOLING_OK;
}

// 从相同节点，借用内存执行RPC函数，发送到从节点执行，需要传入执行的节点Nid
MpResult MemBorrowExecutor::SmapMigreatBackRpc(const std::string importNodeId, const MigrateBackMsg& migrateBackMsg)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] Master invoke the agent SmapMigreatBackRpc, importNodeId=" << importNodeId << ".";

    MpResult ret = SmapMigrateBackProcess(migrateBackMsg);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Smap migrate back execute failed.";
        return ret;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] Smap migrate back execute success.";
    return MEM_POOLING_OK;
}

void PersistenceSmapEnable(const int16_t& numaId)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemReturn] Start to PersistenceSmapEnable numaId=" << numaId << ".";
    MpResult retSmapEnableCompleted = SmapEnableCompleted::Instance().Update(numaId);
    if (retSmapEnableCompleted != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemReturn] Update SmapEnableCompleted numaId failed. ret=" << retSmapEnableCompleted << ".";
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemReturn] Update SmapEnableCompleted numaId success.";
    }
}

void DeletePersistenceSmapEnable(const int16_t& numaId)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemReturn] Delete PersistenceSmapEnable numaId=" << numaId << ".";
    MpResult retSmapEnableCompleted = SmapEnableCompleted::Instance().Remove(numaId);
    if (retSmapEnableCompleted != MEM_POOLING_OK) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemReturn] Delete PersistenceSmapEnable numaId failed. ret=" << retSmapEnableCompleted << ".";
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemReturn] Delete PersistenceSmapEnable pids success.";
    }
}

static MpResult DispatchMigrateBackIfNeeded(const std::string& name, std::vector<MigrateBackMsg>& msgs,
                                            const EnableNodeMsg& enableMsg, std::vector<uint64_t>& taskIds)
{
    if (SmapMigrateBackTaskIds::Instance().Query(name, taskIds) == MEM_POOLING_OK && !taskIds.empty()) {
        return MEM_POOLING_OK;
    }
    for (auto& msg : msgs) {
        if (msg.count <= 0) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Smap migrate back count=" << msg.count << " invalid.";
            return MEM_POOLING_ERROR;
        }
        PersistenceSmapEnable(static_cast<int16_t>(msg.payload[0].srcNid));
        if (SmapMigrateBackProcess(msg) != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Smap migrate back execute failed.";
            if (SmapEnableNumaProcess(enableMsg) == MEM_POOLING_OK) {
                DeletePersistenceSmapEnable(static_cast<int16_t>(msg.payload[0].srcNid));
            }
            return MEM_POOLING_ERROR;
        }
        taskIds.push_back(msg.taskID);
    }
    if (!taskIds.empty()) {
        SmapMigrateBackTaskIds::Instance().Update(name, taskIds);
    }
    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::MemFreeWithOpsBySmapForProcessMem(const UbseNumaMemoryDebtInfo& matchedDebtInfo,
                                                              const std::vector<UbseNumaMemoryDebtInfo>& debtInfos,
                                                              bool isFault)
{
    std::vector<MigrateBackMsg> migrateBackMsgs;
    EnableNodeMsg enableMsg;
    auto retSmap = GenerateSmapParamsForProcessMem(matchedDebtInfo, migrateBackMsgs, enableMsg);
    auto name = matchedDebtInfo.name;
    if (retSmap != MEM_POOLING_OK || migrateBackMsgs.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] GenerateParams failed, ret=" << retSmap << ".";
        return MEM_POOLING_ERROR;
    }
    if (UpdateSmapRemoteNumaInfoBeforeMigrateBack(matchedDebtInfo, debtInfos) != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] UpdateSmapRemoteNumaInfoBeforeMigrateBack failed.";
        return MEM_POOLING_ERROR;
    }

    std::vector<uint64_t> taskIds;
    if (DispatchMigrateBackIfNeeded(name, migrateBackMsgs, enableMsg, taskIds) != MEM_POOLING_OK) {
        return MEM_POOLING_ERROR;
    }
    for (const auto& taskId : taskIds) {
        auto ret = MpSmapHelper::GetLocalSmapBackResult(taskId);
        if (ret != MEM_POOLING_OK) {
            (ret != MEM_POOLING_MIGRATE_TIMEOUT) && SmapMigrateBackTaskIds::Instance().Remove(name);
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] GetLocalSmapBackResult failed, taskId=" << taskId << ".";
            return MEM_POOLING_ERROR;
        }
    }
    SmapMigrateBackTaskIds::Instance().Remove(name);

    auto ret = MemFreeWithOpsByMemfabric(name, name, isFault);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] MemFreeWithOpsByMemfabric failed.";
    } else {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemBorrowExecute] MemBorrowExecutor frees memory success, borrow_id=" << name << ".";
        MemReturnManager::Instance().RemovePendingReturn(name);
    }
    retSmap = SmapEnableNumaProcess(enableMsg);
    if (retSmap != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] SmapEnableNumaProcess failed.";
        return MEM_POOLING_ERROR;
    } else {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] SmapEnableNumaProcess success.";
        DeletePersistenceSmapEnable(static_cast<int16_t>(migrateBackMsgs[0].payload[0].srcNid));
    }

    return ret;
}

bool CheckCriticalError(int numaId)
{
    // 为1代表NUMA故障直接归还，其他情况继续执行
    std::string filePath = "/sys/devices/system/node/node" + std::to_string(numaId) + "/critical_err";
    std::ifstream file(filePath);
    if (!file.is_open()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "Node " << numaId << ": File " << filePath << " not found or permission denied.";
        return false;
    }
    std::string content;
    if (!(file >> content)) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "Node " << numaId << ": Failed to read file content.";
        return false;
    }

    if (content == "1") {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "Node " << numaId << ": critical_error is 1.";
        return true;
    }

    return false;
}

MpResult MemBorrowExecutor::MemFreeWithOpsBySmap(const std::string& name, const std::string& deleteName, bool isFault)
{
    std::vector<MigrateBackMsg> migrateBackMsgList;
    EnableNodeMsg enableMsg;
    std::string importNodeId;
    auto retSmap = GenerateSmapParams(deleteName, migrateBackMsgList, enableMsg, importNodeId, isFault);
    if (retSmap != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] GenerateParams failed.";
        return retSmap;
    }
    if (migrateBackMsgList.empty()) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Smap migrate back msg list is empty.";
        return MEM_POOLING_ERROR;
    }
    // 持久化SmapEnable数据（只需一次，基于第一个消息的srcNid）
    PersistenceSmapEnable(static_cast<int16_t>(migrateBackMsgList[0].payload[0].srcNid));

    for (auto& migrateBackMsg : migrateBackMsgList) {
        retSmap = SmapMigrateBackProcess(migrateBackMsg);
        if (retSmap != MEM_POOLING_OK) {
            int numaId = migrateBackMsg.payload[0].srcNid;
            if (CheckCriticalError(numaId)) {
                break;
            }
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Smap migrate back execute failed.";
            retSmap = SmapEnableNumaProcess(enableMsg);
            if (retSmap != MEM_POOLING_OK) {
                UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[MemFree][MemFreeExecute] SmapEnableNumaProcess failed.";
            } else {
                // 迁回失败并对远端numa进行了enable，把持久化数据删掉
                DeletePersistenceSmapEnable(static_cast<int16_t>(migrateBackMsg.payload[0].srcNid));
            }
            return MEM_POOLING_ERROR;
        }
    }

    auto retMemFreeByUbse = MemFreeWithOpsByMemfabric(name, deleteName, isFault);
    if (retMemFreeByUbse != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] MemFreeWithOpsByMemfabric failed.";
    } else {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemBorrowExecute] MemBorrowExecutor frees memory success, borrow_id=" << name << ".";
    }

    retSmap = SmapEnableNumaProcess(enableMsg);
    if (retSmap != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] SmapEnableNumaProcess failed.";
        return MEM_POOLING_ERROR;
    } else {
        // 归还成功并对远端numa进行了enable，把持久化数据删掉
        DeletePersistenceSmapEnable(static_cast<int16_t>(migrateBackMsgList[0].payload[0].srcNid));
    }

    return retMemFreeByUbse;
}

MpResult MemBorrowExecutor::MemFreeWithOpsByMemfabric(const std::string& name, const std::string& deleteName,
                                                      bool isFault)
{
    std::vector<BorrowRecord> borrowRecords;
    auto retCode = BorrowRecordHelper::Instance().CollectBorrowRecordsAll(borrowRecords, isFault);
    if (retCode != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Collect all borrowRecords failed.";
        return retCode;
    }
    UbseMemBorrower borrower;
    borrower.nodeId = name.substr(0, name.find('-'));

    UbseResult ret = UbseMemNumaDelete(deleteName, borrower);
    if (isFault && ret == UBSE_ERR_UNIMPORT_SUCCESS) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute][FaultHandle] Free memory of borrowId=" << name
            << " unimport success in fault handle. Ret_code=" << static_cast<int>(ret) << ".";
    } else if (ret != UBSE_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Free memory of borrowId " << name
            << " by memfabric failed. Ret_code=" << static_cast<int>(ret) << ".";
        if (ret == UBSE_ERR_TIMEOUT) {
            return HandleTimeoutFree(name, borrowRecords);
        }
        return static_cast<uint32_t>(ret);
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemBorrowExecute] MemBorrowExecutor frees memory success, borrow_id=" << name << ".";

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::HandleTimeoutFree(const std::string& name, const std::vector<BorrowRecord>& borrowRecords)
{
    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] RackManager return err code is unknown, code=RUNNING, change to TIMEOUT.";
    // 然后从中过滤出name
    for (auto& record : borrowRecords) {
        if (record.name == name) {
            BorrowItem item{name,
                            record.borrowNode,
                            static_cast<uint16_t>(record.borrowRemoteNuma),
                            record.lentNode,
                            record.lentSocketId,
                            0};
            auto retCode = MemReturnManager::Instance().Update(name, item);
            if (retCode != MEM_POOLING_OK) {
                UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[MemFree][MemFreeExecute] Update borrowId=" << name << " failed.";
                return retCode;
            }
            if (!MemReturnScanner::Instance().start()) {
                UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                    << "[MemFree][MemFreeExecute] Start borrow return scanner failed.";
                return MEM_POOLING_ERROR;
            }
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Free memory of borrowId=" << name
                << " , remoteNumaId=" << static_cast<uint16_t>(record.borrowRemoteNuma)
                << " ,lentNode=" << record.lentNode << " ,lentSocketId=" << record.lentSocketId << " time out.";
            break;
        }
    }
    return static_cast<uint32_t>(UBSE_ERR_TIMEOUT);
}

MpResult MemBorrowExecutor::MemFreeWithOps(const std::string& name, bool isForceDelete, bool smapBack, bool isFault)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] MemBorrowExecutor starts to free memory, borrowI_id=" << name << ".";

    std::string deleteName = name;

    int redirectCount = 0;
    std::string redirectNameKey = name;
    std::string redirectNameVal = name;
    do {
        redirectNameKey = redirectNameVal;
        redirectNameVal.clear();
        MpResult retDirect = BorrowIdRedirection::Instance().Query(redirectNameKey, redirectNameVal);
        if (retDirect != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Get redirection of borrow_id=" << name << " err=" << retDirect << ".";
            return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
        }
        if (++redirectCount > MAX_REDIRECT_COUNT) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Redirection chain too long for borrow_id=" << name
                << " chainLength=" << redirectCount << ".";
            return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
        }
    } while (!redirectNameVal.empty());

    deleteName = redirectNameKey;
    if (deleteName != name) {
        UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] BorrowId=" << name << " rediects to borrow_id=" << deleteName << ".";
    }

    if (smapBack) {
        auto ret = MemFreeWithOpsBySmap(name, deleteName, isFault);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] MemFreeWithOpsBySmap failed, borrow_id=" << name << " err=" << ret << ".";
            return ret;
        }
    } else {
        auto ret = MemFreeWithOpsByMemfabric(name, deleteName, isFault);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] MemFreeWithOpsByMemfabric failed, borrow_id=" << name << " err=" << ret
                << ".";
            return ret;
        }
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemBorrowExecute] MemBorrowExecutor frees memory success, borrow_id=" << name << ".";

    MpResult retDirect = RemoveBorrowIdRedirectionRecursively(name);
    if (retDirect != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] Remove redirection of borrow_id=" << name << " err=" << retDirect << ".";
        return MEM_POOLING_FAULT_RETURN_MEM_ERROR;
    }

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::MemFreeWithOpsForProcessMem(const std::string& name, bool smapBack, bool isFault)
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] MemBorrowExecutor starts to free memory, borrowI_id=" << name << ".";

    MemReturnManager::Instance().AddPendingReturn(name);
    if (smapBack) {
        UbseNumaMemoryDebtInfo matchedDebtInfo;
        std::vector<UbseNumaMemoryDebtInfo> debtInfos;
        auto debtResult =
            GetDebtInfoByNameWithRetry(name, MpConfiguration::GetInstance().GetNodeId(), debtInfos, matchedDebtInfo);
        if (debtResult.validEntry != MEM_POOLING_OK) {
            if (debtResult.releasedEntry == MEM_POOLING_OK) {
                UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE) << "[MemFree][MemFreeExecute] borrow_id=" << name
                                                                 << " has already been released, skip free this round.";
                return MEM_POOLING_OK;
            }
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] GetDebtInfoByNameWithRetry failed, borrowId=" << name << ".";
            return MEM_POOLING_ERROR;
        }

        // 对匹配的远端NUMA加本机锁，防止并发操作同一NUMA
        FaultNumaLockGuard lockGuard;
        auto numaId = static_cast<uint16_t>(matchedDebtInfo.remoteNumaId);
        MpResult lockRet = FaultNumaLock::Instance().TryAcquireSelf(numaId);
        if (lockRet != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] Fault NUMA locked, numaId=" << numaId << ", borrowId=" << name
                << ", ret=" << lockRet << ".";
            return lockRet;
        }
        lockGuard.selfNumaIds.push_back(numaId);

        auto ret = MemFreeWithOpsBySmapForProcessMem(matchedDebtInfo, debtInfos, isFault);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] MemFreeWithOpsBySmap failed.";
            return ret;
        }
    } else {
        auto ret = MemFreeWithOpsByMemfabric(name, name, isFault);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[MemFree][MemFreeExecute] MemFreeWithOpsByMemfabric failed.";
            return ret;
        }
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemBorrowExecute] MemBorrowExecutor frees memory success, borrow_id=" << name << ".";

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::GenerateUniqueId(const std::string& nodeId, std::string& str, const bool isFault)
{
    // 1. 纳秒级时间戳
    uint64_t ts =
        std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch())
            .count();

    // 2. 进程内递增计数器（防止同一时间戳内冲突）
    static std::atomic<uint32_t> counter{0};
    uint32_t seq = counter.fetch_add(1, std::memory_order_relaxed);

    // 3. 轻量随机扰动（不依赖 random_device）
    uint32_t mix = static_cast<uint32_t>(ts ^ (ts >> 32) ^ seq);

    // 4. 拼成 128 bit = 32 hex
    std::stringstream ss;
    ss << std::hex << std::setfill('0') << std::setw(16) << ts // 64 bit
       << std::setw(8) << seq                                  // 32 bit
       << std::setw(8) << mix;                                 // 32 bit

    str = nodeId + "-" + ss.str();
    if (isFault) {
        str += "-rep";
    }

    return MEM_POOLING_OK;
}

MpResult MemBorrowExecutor::FindCurrentDebtInfoAndSrcNuma(const UbseNumaMemoryDebtInfo& matchedDebtInfo,
                                                          int& outSrcNuma)
{
    process_mem::def::ProcessMemUsrInfo usrInfo{};
    errno_t err = memcpy_s(&usrInfo, sizeof(process_mem::def::ProcessMemUsrInfo), matchedDebtInfo.usrInfo,
                           sizeof(process_mem::def::ProcessMemUsrInfo));
    if (err != 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] memcpy_s usrInfo failed, err=" << err;
        return MEM_POOLING_ERROR;
    }

    outSrcNuma = usrInfo.srcNuma;
    if (outSrcNuma == -1) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] srcNuma is invalid(-1), skip SetSmapRemoteNumaInfo, borrowId="
            << matchedDebtInfo.name;
        return MEM_POOLING_OK;
    }

    return MEM_POOLING_OK;
}

bool MemBorrowExecutor::IsValidBorrowIdFormat(const UbseNumaMemoryDebtInfo& debtInfo)
{
    // Check usrInfo first 4 bytes (pluginId) is PROCESS_MEM
    uint32_t pluginId = 0;
    auto err = memcpy_s(&pluginId, sizeof(pluginId), debtInfo.usrInfo, sizeof(pluginId));
    if (err != 0) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE) << "memcpy_s usrInfo failed, err=" << err;
        return false;
    }
    if (pluginId != static_cast<uint32_t>(process_mem::def::UsrInfoPluginType::PROCESS_MEM)) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "borrowId " << debtInfo.name << " pluginId is " << pluginId << ".";
        return false;
    }

    // Check name format: nodeId-xxx where nodeId is all digits and valid
    const std::string& name = debtInfo.name;
    auto dashPos = name.find('-');
    if (dashPos == std::string::npos || dashPos == 0 || dashPos == name.size() - 1) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "borrowId " << debtInfo.name << " excluded.";
        return false;
    }
    std::string nodeIdPart = name.substr(0, dashPos);
    for (char c : nodeIdPart) {
        if (!std::isdigit(static_cast<unsigned char>(c))) {
            UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "borrowId " << debtInfo.name << " excluded.";
            return false;
        }
    }
    auto allNodes = ubse::nodeController::UbseNodeController::GetInstance().GetAllNodes();
    std::unordered_set<std::string> validNodeIds;
    for (const auto& [nodeId, _] : allNodes) {
        validNodeIds.insert(nodeId);
    }
    return validNodeIds.count(nodeIdPart) > 0;
}

std::vector<UbseNumaMemoryDebtInfo> MemBorrowExecutor::FilterValidDebtInfos(
    const std::vector<UbseNumaMemoryDebtInfo>& debtInfos)
{
    std::vector<UbseNumaMemoryDebtInfo> validDebtInfos;
    for (const auto& debtInfo : debtInfos) {
        if (IsValidBorrowIdFormat(debtInfo)) {
            validDebtInfos.push_back(debtInfo);
        }
    }
    return validDebtInfos;
}

uint64_t MemBorrowExecutor::SumDebtInfosSizeBytesForRemoteNuma(const std::vector<UbseNumaMemoryDebtInfo>& debtInfos,
                                                               int16_t remoteNumaId)
{
    uint64_t totalSizeBytes = 0;
    for (const auto& debtInfo : debtInfos) {
        if (debtInfo.remoteNumaId == remoteNumaId) {
            totalSizeBytes += debtInfo.size;
        }
    }
    return totalSizeBytes;
}

static void FilterInvalidRemoteNumaDebtInfos(std::vector<UbseNumaMemoryDebtInfo>& debtInfos)
{
    size_t before = debtInfos.size();
    debtInfos.erase(std::remove_if(debtInfos.begin(), debtInfos.end(),
                                   [](const UbseNumaMemoryDebtInfo& info) { return info.remoteNumaId < 0; }),
                    debtInfos.end());
    if (debtInfos.size() != before) {
        UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrowExecutor] Filtered " << (before - debtInfos.size())
            << " debtInfos with remoteNumaId < 0, remain " << debtInfos.size() << ".";
    }
}

bool MemBorrowExecutor::ShouldRetryDebtInfoFetch(UbseResult ret, const std::vector<UbseNumaMemoryDebtInfo>& debtInfos)
{
    if (ret == UBSE_ERR_INTERNAL) {
        return true;
    }
    if (ret != UBSE_OK && debtInfos.empty()) {
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] UbseGetNumaMemDebtInfo failed, ret=" << ret
            << ", debtInfos is empty, need retry.";
        return true;
    }
    return false;
}

MpResult MemBorrowExecutor::GetDebtInfosWithRetry(std::vector<UbseNumaMemoryDebtInfo>& debtInfos)
{
    constexpr int maxRetryTimes = 30;
    constexpr int sleepSeconds = 1;
    int curRetryTimes = 0;

    while (curRetryTimes < maxRetryTimes) {
        debtInfos.clear();
        UbseResult ret = UbseGetNumaMemDebtInfo(debtInfos);
        FilterInvalidRemoteNumaDebtInfos(debtInfos);
        if (!ShouldRetryDebtInfoFetch(ret, debtInfos)) {
            return MEM_POOLING_OK;
        }
        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemBorrowExecutor] UbseGetNumaMemDebtInfo retry=" << (curRetryTimes + 1)
            << ", ret=" << static_cast<uint32_t>(ret);
        std::this_thread::sleep_for(std::chrono::seconds(sleepSeconds));
        curRetryTimes++;
    }

    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemBorrowExecutor] UbseGetNumaMemDebtInfo failed after max retry.";
    return MEM_POOLING_ERROR;
}

DebtQueryResult MemBorrowExecutor::GetDebtInfoByNameWithRetry(const std::string& name, const std::string& nodeId,
                                                              std::vector<UbseNumaMemoryDebtInfo>& debtInfos,
                                                              UbseNumaMemoryDebtInfo& matchedDebtInfo)
{
    constexpr int maxRetryTimes = 5;
    constexpr int sleepSeconds = 1;
    int curRetryTimes = 0;

    while (curRetryTimes < maxRetryTimes) {
        debtInfos.clear();
        UbseResult ret = UbseGetNumaMemDebtInfoWithNode(nodeId, debtInfos);
        matchedDebtInfo = UbseNumaMemoryDebtInfo{};
        bool hasPositiveRemoteNuma = false;
        bool hasNegativeRemoteNuma = false;
        for (const auto& debtInfo : debtInfos) {
            if (debtInfo.name != name) {
                continue;
            }
            if (debtInfo.remoteNumaId < 0) {
                hasNegativeRemoteNuma = true;
                continue;
            }
            hasPositiveRemoteNuma = true;
            matchedDebtInfo = debtInfo;
        }
        if (hasNegativeRemoteNuma) {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[DebtQuery] borrowId=" << name << " has negative remoteNumaId.";
            return {hasPositiveRemoteNuma ? MEM_POOLING_OK : MEM_POOLING_ERROR, MEM_POOLING_OK};
        }
        if (hasPositiveRemoteNuma) {
            UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[DebtQuery] borrowId=" << name << " has positive remoteNumaId.";
            return {MEM_POOLING_OK, MEM_POOLING_ERROR};
        }
        if (MemBorrowExecutor::ShouldRetryDebtInfoFetch(ret, debtInfos)) {
            UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[DebtQuery] UbseGetNumaMemDebtInfo retry=" << (curRetryTimes + 1)
                << ", ret=" << static_cast<uint32_t>(ret);
            std::this_thread::sleep_for(std::chrono::seconds(sleepSeconds));
            curRetryTimes++;
            continue;
        }

        UBSE_LOGGER_WARN(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[DebtQuery] borrowId=" << name << " not found in debt info, retry=" << (curRetryTimes + 1);
        std::this_thread::sleep_for(std::chrono::seconds(sleepSeconds));
        curRetryTimes++;
    }

    UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[DebtQuery] borrowId=" << name << " not found in debt info after max retry.";
    return {MEM_POOLING_ERROR, MEM_POOLING_ERROR};
}

MpResult MemBorrowExecutor::UpdateSmapRemoteNumaInfoBeforeMigrateBack(
    const UbseNumaMemoryDebtInfo& matchedDebtInfo, const std::vector<UbseNumaMemoryDebtInfo>& debtInfos)
{
    int srcNuma = 0;
    MpResult findRet = FindCurrentDebtInfoAndSrcNuma(matchedDebtInfo, srcNuma);
    if (findRet != MEM_POOLING_OK) {
        return findRet;
    }

    // totalSizeBytes 为该 remoteNumaId 下所有有效账本条目 size 之和（扣除当前迁回条目后为剩余共享量）
    auto validDebtInfos = FilterValidDebtInfos(debtInfos);
    uint64_t totalSizeBytes = SumDebtInfosSizeBytesForRemoteNuma(validDebtInfos, matchedDebtInfo.remoteNumaId);

    return ValidateAndExecuteSmapUpdate(&matchedDebtInfo, totalSizeBytes, srcNuma, matchedDebtInfo.name);
}

MpResult MemBorrowExecutor::ValidateAndExecuteSmapUpdate(const UbseNumaMemoryDebtInfo* currentDebtInfo,
                                                         uint64_t totalSizeBytes, int srcNuma, const std::string& name)
{
    if (currentDebtInfo->size > totalSizeBytes) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] totalSizeBytes=" << totalSizeBytes
            << " < currentDebtInfo->size=" << currentDebtInfo->size
            << ", possible debt data inconsistency, borrowId=" << name;
        return MEM_POOLING_ERROR;
    }

    uint64_t remainingSizeBytes = totalSizeBytes - currentDebtInfo->size;
    uint64_t remainingSizeKB = remainingSizeBytes / 1024;

    auto ret = SetSmapRemoteNumaInfoExec(static_cast<int16_t>(-1), static_cast<uint16_t>(currentDebtInfo->remoteNumaId),
                                         remainingSizeKB);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[MemFree][MemFreeExecute] SetSmapRemoteNumaInfoExec failed, srcNuma=" << srcNuma
            << ", remoteNuma=" << currentDebtInfo->remoteNumaId << ", remainingSizeKB=" << remainingSizeKB;
        return MEM_POOLING_ERROR;
    }

    UBSE_LOGGER_INFO(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[MemFree][MemFreeExecute] UpdateSmapRemoteNumaInfoBeforeMigrateBack: srcNuma=" << srcNuma
        << ", remoteNuma=" << currentDebtInfo->remoteNumaId << ", totalSize=" << totalSizeBytes << " B"
        << ", returnSize=" << currentDebtInfo->size << " B, remainingSize=" << remainingSizeKB << " KB";

    return MEM_POOLING_OK;
}

MpResult MpMemBorrowExecutorModule::DeleteFailedBorrowIds()
{
    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE) << "[Reliability][MemFree] Start freeing borrowIds.";

    std::vector<std::string> borrowIdListNeedToFree;

    MpResult ret = BorrowIdsCompleted::Instance().Query(borrowIdListNeedToFree);
    if (ret != MEM_POOLING_OK) {
        UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
            << "[Reliability][MemFree] Get borrowed borrowId list failed.";
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[Reliability][MemFree] The number of borrowIds need to free is " << borrowIdListNeedToFree.size() << ".";

    int borrowIdFreedCnt = 0;

    for (const auto& borrowId : borrowIdListNeedToFree) {
        ret = MemBorrowExecutor::Instance().MemFreeWithOps(borrowId, false, true);
        if (ret != MEM_POOLING_OK) {
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[Reliability][MemFree] Mem free by executor failed, borrowId: " << borrowId;
            continue;
        }
        ret = BorrowIdsCompleted::Instance().Remove(borrowId);
        if (ret != MEM_POOLING_OK) {
            // 可靠性保障，如果失败，不影响主功能
            UBSE_LOGGER_ERROR(MP_MODULE_NAME, MP_MODULE_CODE)
                << "[Reliability][MemFree] Remove borrowed borrowId failed, borrowId is " << borrowId << ".";
        }
        borrowIdFreedCnt++;
    }

    UBSE_LOGGER_DEBUG(MP_MODULE_NAME, MP_MODULE_CODE)
        << "[Reliability][MemFree] The number of borrowIds freed is " << borrowIdFreedCnt;

    return MEM_POOLING_OK;
}

} // namespace mempooling