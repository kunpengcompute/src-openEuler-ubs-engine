/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 
 * UBS RMRS is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
*/

#ifndef MP_MODULE_H
#define MP_MODULE_H

#include <string>

#include "mp_error.h"

namespace mempooling {

class MpSubModule {
public:
    virtual ~MpSubModule() = default;

    virtual MpResult Init() = 0;

    virtual void DeInit() = 0;

    virtual const std::string Name() = 0;
};

} // namespace mempooling
#endif