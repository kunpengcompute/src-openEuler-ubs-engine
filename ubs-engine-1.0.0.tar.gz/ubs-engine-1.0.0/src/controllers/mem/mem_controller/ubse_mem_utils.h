/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef UBSE_MEM_UTILS_H
#define UBSE_MEM_UTILS_H

#include <ubse_mem_resource.h>
#include <vector>
#include "ubse_common_def.h"
#include "ubse_thread_pool_module.h"

namespace ubse::mem::utils {
using namespace ubse::task_executor;
using ubse::common::def::UbseResult;
using namespace ubse::resource::mem;

std::string GetCurNodeId();
UbseTaskExecutorPtr GetExecutor(const std::string& name);
void FilterFdAndNumaObjs(NodeMemDebtInfoMap& filterData, const NodeMemDebtInfoMap& data);
}  // namespace ubse::mem::utils
#endif  // UBSE_MEM_UTILS_H
