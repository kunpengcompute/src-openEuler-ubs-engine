/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 *
 * virtagent is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef VM_SYSTEM_UTIL_H
#define VM_SYSTEM_UTIL_H

#include <string>

namespace vm {

class VmSystemUtil {
public:
    /**
     * @brief Get user name by uid
     * @param uid const uid_t: uid
     * @return std::string: username
     */
    static std::string GetUsernameByUid(const uid_t uid);
};
} // namespace vm

#endif
