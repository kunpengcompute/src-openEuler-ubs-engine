/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 *
 * virtagent is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef VM_POINTER_PROCESS_H
#define VM_POINTER_PROCESS_H

namespace vm {
template <typename T> void SafeDeleteArray(T *&ptr)
{
    if (ptr) {
        delete[] ptr;
        ptr = nullptr;
    }
}
template <typename T> void SafeDeleteArray(T *&ptr, size_t ptrLen)
{
    if (ptr && ptrLen != 0) {
        delete[] ptr;
        ptr = nullptr;
    }
}
}
#endif // VM_POINTER_PROCESS_H
