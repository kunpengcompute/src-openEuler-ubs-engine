# 内存池化

## 1. 检查各节点内存池化功能健康状态

### 描述

检查各节点内存池化功能健康状态

### 用法

```shell
ubsectl check memory
```

### 输入参数

无

### 约束限制

ubsectl只能在root，ubse用户中运行

### 输出信息说明

| 字段名 | 字段描述                                                     | 取值范围                                                                                                        |
| ------ | ------------------------------------------------------------ |-------------------------------------------------------------------------------------------------------------|
| node   | 节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串                                                                                                         |
| status | 节点的内存借用功能健康状态，当各组件健康状态均为ok时，取值ok                     | 可选值：[ ok \| nok ]                                                                                           |
| detail | 内存借用功能所依赖的各个组件的健康状态，包括节点集群状态、obmm 内核模块插入状态以及 sysSentry 服务状态。各状态的判定规则为：<br/> 1. 节点集群状态：ok，节点处于 Smoothing 或 Working 状态。  nok：节点处于其他非正常状态 <br/>2. obmm 内核模块状态：ok，模块已正确插入；nok：模块未插入；unknown：节点未上报状态，或集群状态为 Unknown（无法获取信息） <br/>3. sysSentry 服务状态：ok，服务运行正常；nok：服务运行异常；unknown：节点未上报状态，或集群状态为 Unknown（无法获取信息）                                  | cluster state: [ ok \| nok ]; <br/>obmm: [ ok \| nok \| unknown ]; <br/>sysSentry: [ ok \| nok \| unknown ] |

### 示例

#### 场景1：节点重启中，备节点无法连上master节点

- master节点

```bash
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-(2)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
-----------------------------------------------------------------------------------------------------
```

- 备节点

```bash
$ ubsectl check memory
ERROR: Failed to obtain memory information
```

#### 场景2：节点启动稳定后

- master节点

```bash
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
computer02(2)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-----------------------------------------------------------------------------------------------------

```

- 备节点

``` bash
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
computer02(2)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-----------------------------------------------------------------------------------------------------

```

#### 场景3：只有主节点启动，备节点不启动

- master节点

```bash 
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-(2)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
-----------------------------------------------------------------------------------------------------

```

- 备节点

```bash
$ ubsectl check memory
ERROR: Internal error with error code 5

```

#### 场景4：稳定后备节点停掉

- master节点

```bash 
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-(2)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
-----------------------------------------------------------------------------------------------------

```

- 备节点

```bash  
$ ubsectl check memory
ERROR: Internal error with error code 5

```

#### 场景5：稳定后主节点停掉

- master节点

```bash  
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
-(1)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
computer02(2)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
-----------------------------------------------------------------------------------------------------

```

- 备节点

```bash  
$ ubsectl check memory
ERROR: Internal error with error code 5

```

#### 场景6：主节点集群状态、sysSentry服务状态正常，obmm内核模块未插入

- master节点

```bash  
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         nok                     cluster state: ok; obmm: nok; sysSentry: ok
-(2)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
-----------------------------------------------------------------------------------------------------

```

#### 场景7：主节点集群状态、obmm内核模块正确插入，sysSentry服务状态异常

- master节点

```bash 
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         nok                     cluster state: ok; obmm: ok; sysSentry: nok
-(2)                  nok                     cluster state: nok; obmm: unknown; sysSentry: unknown
-----------------------------------------------------------------------------------------------------

```

#### 场景8：备节点处于故障状态，obmm内核模块正确插入、sysSentry服务状态正常

- 备节点

```bash 
$ ubsectl check memory
-----------------------------------------------------------------------------------------------------
node                  status                  detail
-----------------------------------------------------------------------------------------------------
computer01(1)         ok                      cluster state: ok; obmm: ok; sysSentry: ok
computer02(2)         nok                     cluster state: nok; obmm: ok; sysSentry: ok
-----------------------------------------------------------------------------------------------------

```

## 2. 查询各节点内存借入信息

### 描述

查询当前集群中，各节点内存借入信息

### 用法

```shell
ubsectl display memory -t node_borrow
```

### 输入参数

无

### 约束限制

只显示集群中在位的节点，如果脱离集群或未启动，则不显示

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

### 输出信息说明

- 显示信息中的字段说明：

| 字段名  | 字段描述                                                     | 字段取值 |
| ------ | ------------------------------------------------------------ | -------- |
| node   | 借入节点信息。例：computer1(1)<br>节点信息由2部分组成：<br>1.括号前部分：主机名<br>2.括号内部分：节点的槽位号    | 字符串   |
| lend | 借出节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串   |
| size   | 借用内存总量，单位: MB                                       | 整数     |

### 示例

```bash
$ ubsectl display memory -t node_borrow
--------------------------------------------
node          lend             size   
node-1(1)     node-2(2)        450   
node-1(1)     node-3(3)        450   
node-4(4)     node-3(3)        100   

```

## 3. 查询各节点内存借出信息

### 描述

查询当前集群中，各节点内存借出信息

### 用法

```shell
ubsectl display memory -t node_lend
```

### 输入参数

无

### 约束限制

只显示集群中在位的节点，如果脱离集群或未启动，则不显示

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

### 输出信息说明

- 显示信息中的字段说明：

| 字段名    | 字段描述                                                     | 字段取值 |
| -------- | ------------------------------------------------------------ | -------- |
| node     | 借出节点信息。例：computer1(1)<br>节点信息由2部分组成：<br>1.括号前部分：主机名<br>2.括号内部分：节点的槽位号 | 字符串   |
| borrow   | 借入节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串   |
| size     | 借用内存总量，单位: MB                                       | 整数     |

### 示例

```bash
$ ubsectl display memory -t node_lend
--------------------------------------------
node          borrow         size   
node-1(1)     node-2(2)        450   
node-1(1)     node-3(3)        450   
node-4(4)     node-3(3)        100   

```

## 4. 查询内存借用账本详细信息

### 描述

查询当前集群中，所有内存借用账本详细信息, 并支持根据内存名和内存类型过滤查询账本

### 用法

```shell
ubsectl display memory -t borrow_detail [-bt <type>] [-n <name>]
```

### 输入参数

| 字段名                | 字段描述                                                     | 字段取值                                                     |
| --------------------- | ------------------------------------------------------------ | ---------------------------------------------------------- |
| -bt<br/>--borrow-type | 可选，根据借用类型过滤                                       | 可选值：[ numa \| fd \| share ]                                    |
| -n<br/>--name         | 可选，根据内存名过滤<br/>各个节点、各个类型的同名内存都会显示 | 字符串，长度为1~47，仅可包括大小写字母、数字、"."、":"、"-"以及"_" |

### 约束限制

只显示集群中在位的节点，如果脱离集群或未启动，则不显示

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

`fd`和`numa`类型的name在本节点唯一，`share`类型的name在集群内唯一

### 输出信息说明

- 显示信息中的字段说明：

| 字段名       | 字段描述                                                     | 字段取值                                                                                                                                      |
| ----------- | ------------------------------------------------------------ |-------------------------------------------------------------------------------------------------------------------------------------------|
| name        | 一次内存借用的名称                                             | 字符串                                                                                                                                       |
| type        | 内存借用的类型                                                | 可选值：[ numa \| fd \| share ]                                                                                                                     |
| borrow_node | 借入节点信息。例：computer1(1)<br>节点信息由2部分组成：<br>1.括号前部分：主机名<br>2.括号内部分：节点的槽位号 | 字符串                                                                                                                                       |
| lend_node   | 借出节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串                                                                                                                                       |
| lend_numa | 借出numa信息。例：1(216)<br/>numa信息由2部分组成：<br/>1.括号前部分：numaId<br/>2.括号内部分：socketId | 字符串                                                                                                                                       |
| lend_size   | numa节点的借用内存总量，单位: MB                             | 整数                                                                                                                                        |
| status      | 借用状态                                                    | 可选值：<br>done：借用完成<br>exporting：借出节点正在执行导出<br>importing：代入节点正在执行导入<br>unexporting：借出节点正在取消导出<br>unimporting：代入节点正在取消导入<br>fault：当次借用请求出现故障 |
| handle | 资源操作句柄<br/>句柄含义：<br/>numa类型：远端numaId<br/>fd、share类型：内存块标识信息集合 | numa-id: 整数<br/>mem-ids: 整数数组，用,分隔                                                                                                        |

### 示例

查询全量账本

```bash
$ ubsectl display memory -t borrow_detail
------------------------------------------------------------------------------------------------
name         type    borrow_node   lend_node   lend_numa   lend_size       status       handle    
memory1      numa    node-1(1)     node-3(3)   1(216)      100             done         5
memory2      share   node-1(1)     node-3(3)   1(216)      200             done         1,2
memory2      share   node-2(2)     node-3(3)   1(216)      1200            done         3,4
memory3      share                 node-3(3)   1(216)      1200            done         -
memory4      numa    node-2(2)     node-3(3)   1(216)      1300            exporting    -
memory5      fd      node-1(1)     node-3(3)   1(216)      1400            importing    -
memory6      numa                  node-3(3)   1(216)      1300            unexporting  -
memory7      fd      node-1(1)     node-3(3)   1(216)      1400            unimporting  -
memory8      numa    node-2(2)                             1500            fault        -
memory9      fd                    node-3(3)   1(216)      1500            fault        -
------------------------------------------------------------------------------------------------
```

根据类型过滤

```bash
$ ubsectl display memory -t borrow_detail -bt numa
--------------------------------------------------------------------------------------
  name    type   borrow_node     lend_node   lend_numa   lend_size   status   handle   
--------------------------------------------------------------------------------------
  test1   numa   controller(1)   node01(2)   0(36)       128         done     2        
                                                                                      
  test2   numa   controller(1)   node01(2)   0(36)       128         done     2        
                                                                                      
  test    numa   controller(1)   node01(2)   0(36)       2048        done     2        
--------------------------------------------------------------------------------------
```

根据内存名过滤

```bash
$ ubsectl display memory -t borrow_detail -n test
--------------------------------------------------------------------------------------
  name    type   borrow_node     lend_node   lend_numa   lend_size   status   handle   
--------------------------------------------------------------------------------------
  test    fd     controller(1)   node01(2)   0(36)       128         done     1      
                                                                                      
  test    numa   controller(1)   node01(2)   0(36)       128         done     2   
                                                                                       
  test    share  controller(1)   node01(2)   0(36)       512         done     4,5,6,7
  
  test    numa   node02(3)       node01(2)   0(36)       128         done     4  
--------------------------------------------------------------------------------------
```

根据类型和内存名过滤

```bash
$ ubsectl display memory -t borrow_detail -bt numa -n test
-------------------------------------------------------------------------------------
  name   type   borrow_node     lend_node   lend_numa   lend_size   status   handle   
-------------------------------------------------------------------------------------
  test   numa   controller(1)   node01(2)   0(36)       2048        done     2        
-------------------------------------------------------------------------------------
```

## 5. 查询numa状态信息

### 描述

查询当前集群中，所有numa设备的信息

### 用法

```shell
ubsectl display memory -t numa_status
```

### 输入参数

无

### 约束限制

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

### 输出信息说明

- 显示信息中的字段说明：

| 字段名       | 字段描述                                                     | 字段取值 |
| ------------ | ------------------------------------------------------------ | -------- |
| node         | 节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串   |
| numa         | numa id，单位: MB                                            | 整数     |
| total        | NUMA的内存总量，单位: MB                                     | 整数     |
| used         | NUMA的内存使用量，单位: MB                                   | 整数     |
| free         | NUMA的内存空闲量，单位: MB                                   | 整数     |
| used_percent | 内存使用比例, 保留一位小数                                   | 浮点数   |

### 示例

```bash
$ ubsectl display memory -t numa_status
-------------------------------------------------------
node         numa    total   used   free   used_percent
node-1(1)    0       1024    128    896	   12.5       
node-1(1)    1       8192    256    7936   3.1
node-2(2)    0       1024    128    896	   12.5   
```

## 6. 查询全量节点是否可借用内存信息

### 描述

查询全量节点是否可借用内存信息

### 用法

```shell
ubsectl display memory -t config
```

### 输入参数

无

### 约束限制

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

### 输出信息说明

- 显示信息中的字段说明：

| 字段名      | 字段描述                                                     | 字段取值                  |
|----------| ------------------------------------------------------------ |-----------------------|
| node     | 节点信息。例：computer1(1)<br/>节点信息由2部分组成：<br/>1.括号前部分：主机名<br/>2.括号内部分：节点的槽位号 | 字符串                   |
| isLender | 此节点是否可以作为内存借出方                                            | 可选值：[ true \| false ] |

### 示例

```bash
$ ubsectl display memory -t config
-------------------------------------------------------
node         isLender    
-------------------------------------------------------
node-1(1)    true       
node-2(2)    false
-------------------------------------------------------       
```

## 7. 触发内存借用

### 描述

在本节点借用指定类型的内存

### 用法

```shell
# NUMA 类型
ubsectl create memory -t numa -s <size> -n <name> [-l <linkInfo>]
# FD 类型
ubsectl create memory -t fd -s <size> -n <name>
# 共享内存类型
ubsectl create memory -t share -s <size> -n <name> [-r <regionList>]
```

### 输入参数说明

- 输入参数说明：

| 字段名      | 字段描述                         | 字段取值                                          |
|----------|------------------------------|-----------------------------------------------|
| -t<br>--type | 借用类型                         | 可选值：[ numa \| fd \| share ]                       |
| -n<br/>--name | 本次借用的唯一标识                    | 字符串<br/>长度为1~47，仅可包括大小写字母、数字、"."、":"、"-"以及"_" |
| -s<br/>--size | 借用内存大小<br/>单位: MB/GB，不能小于4MB | 整数 + M/G                          |
| -l<br/>--link | 可选参数, 链路id，仅numa类型支持，其他类型不生效 | 字符串                                           |
| -r<br/>--region | 可选参数，共享域节点列表，仅共享借用支持，其他类型不生效 | 用,分隔的**节点槽位号**                                |

### 约束限制

ubsectl只能在root，ubse用户中运行，可管理所有内存资源

`fd`和`numa`类型的name在本节点唯一，`share`类型的name在集群内唯一

`-r`仅`share`类型有效，`-l`仅`numa`类型有效

### 输出信息说明

- **numa类型：**

| 字段名      | 字段描述               | 字段取值 |
| ----------- | ---------------------- | -------- |
| name        | 本次借用的唯一标识     | 字符串   |
| size        | 借用内存大小，单位: MB | 整数     |
| numa-id     | 远端numaId             | 整数     |
| import-node | 借入节点id             | 整数     |
| export-node | 借出节点id             | 整数     |

- **fd类型：**

| 字段名      | 字段描述               | 字段取值          |
| ----------- | ---------------------- | ----------------- |
| name        | 本次借用的唯一标识     | 字符串            |
| size        | 借用内存大小，单位: MB | 整数              |
| mem-ids     | 内存标识信息           | 整数数组，用,分隔 |
| import-node | 借入节点id             | 整数              |
| export-node | 借出节点id             | 整数              |

- **share类型：**

| 字段名      | 字段描述               | 字段取值          |
| ----------- | ---------------------- | ----------------- |
| name        | 本次借用的唯一标识     | 字符串            |
| size        | 借用内存大小，单位: MB | 整数              |
| export-node | 借出节点id             | 整数              |
| region      | 共享域                 | 整数数组，用,分隔 |

### 示例

- **numa 类型**

```bash
$ ubsectl create memory -t numa -l 1/36/0-2/36/0 -s 128M -n testName
name:testName
size:128M
numa-id:5
import-node:1
export-node:2
```

- **fd 类型**

```bash
$ ubsectl create memory -t fd -s 128M -n testName
name:testName
size:128M
mem-ids:1,2,3
import-node:1
export-node:2
```

- **share 类型**

```bash
$ ubsectl create memory -t share -s 128M -n testName -r 1,2
name:testName
size:128M
export-node:2
region:1,2
```

## 8. 删除内存借用记录，释放借用的内存

### 描述

删除命令行调用节点的内存借用记录，释放借用的内存。

### 用法

```shell
ubsectl delete memory [-t <borrow-type>] -n <name>
```

### 输入参数说明

- 输入参数说明：

| 字段名           | 字段描述                                                     | 字段取值                                 |
|---------------| ------------------------------------------------------------ |--------------------------------------|
| -t<br/>--type | 借用类型<br/>默认值: "numa"                                  | 可选值: [ numa \| fd \| share \| addr ] |
| -n<br/>--name | 借用的唯一标识<br/>长度为1~47，仅可包括大小写字母、数字、"."、":"、"-"以及"_" | 字符串                                  |

### 输出信息说明

Delete successfully

### 示例

```bash
$ ubsectl delete memory -t share -n testName
Delete successfully
```

## 9. **导入共享内存**

### **描述**

在本节点导入共享形态的远端内存。

### **用法**

```bash
ubsectl attach memory -n <name>
```

### **输入参数说明**

| 字段名        | 字段描述       | 字段取值                                                     |
| ------------- | -------------- | ------------------------------------------------------------ |
| -n<br/>--name | 借用的唯一标识 | 字符串<br/>长度为1~47，仅可包括大小写字母、数字、"."、":"、"-"以及"_" |

### **输出信息说明**

| 字段名      | 字段描述               | 字段取值          |
| ----------- | ---------------------- | ----------------- |
| name        | 本次借用的唯一标识     | 字符串            |
| size        | 借用内存大小，单位: MB | 整数              |
| mem-ids     | 内存标识信息           | 整数数组，用,分隔 |
| import-node | 借入节点id             | 整数              |
| export-node | 借出节点id             | 整数              |
| region      | 共享域                 | 整数数组，用,分隔 |

### **示例**

```bash
$ ubsectl attach memory -n testName
name:testName
size:128M
mem-ids:1,2,3
import-node:1
export-node:2   
region:1,2
```

## 10. 删除导入共享内存

### **描述**

删除本节点导入的共享形态的远端内存。

### **用法**

```bash
ubsectl detach memory -n <name>
```

### **输入参数说明**

| 字段名        | 字段描述       | 字段取值                                                     |
| ------------- | -------------- | ------------------------------------------------------------ |
| -n<br/>--name | 借用的唯一标识 | 字符串<br/>长度为1~47，仅可包括大小写字母、数字、"."、":"、"-"以及"_" |

### **输出信息说明**

```bash
Detach successfully
```
