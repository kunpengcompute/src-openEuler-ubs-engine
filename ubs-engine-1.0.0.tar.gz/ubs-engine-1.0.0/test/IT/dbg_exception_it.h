/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef DBG_EXCEPTION_IT_H
#define DBG_EXCEPTION_IT_H

#include "ubse_context.h"
#include "main_test_it.h"
#include "ubse_exception_module.h"
#include "exceptionTest.h"

namespace ubse::it::exception {
int32_t ITestCmdExceptionTest(ProcessMmap *pMmap);
}

#endif // DBG_EXCEPTION_IT_H
