/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef SUIT_TEST_IT_INIT_H
#define SUIT_TEST_IT_INIT_H

#include <gtest/gtest.h>

#include "main_test_it.h"

namespace ubse::it {
class TestITInit : public testing::Test {
public:
    TestITInit();

    virtual void SetUp();

    virtual void TearDown();

    static void SetUpTestSuite();

    static void TearDownTestSuite();

private:
    static ProcessMmap *pMmap;
};
} // namespace ubse::it

#endif
