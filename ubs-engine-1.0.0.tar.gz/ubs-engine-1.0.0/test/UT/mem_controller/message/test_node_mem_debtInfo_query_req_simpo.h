/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef UBSE_MANAGER_TEST_NODE_MEM_DEBTINFO_QUERY_REQ_SIMPO_H
#define UBSE_MANAGER_TEST_NODE_MEM_DEBTINFO_QUERY_REQ_SIMPO_H

#include "gtest/gtest.h"
#include "mockcpp/mockcpp.hpp"

#include "message/ubse_mem_debt_info_query_req_simpo.h"

namespace ubse::mem::controller::message::ut {
class TestNodeMemDebtInfoQueryReqSimpo : public testing::Test {
public:
    void SetUp() override;

    void TearDown() override;

private:
    NodeMemDebtInfoQueryReqSimpoPtr obj;
};
} // namespace ubse::mem::controller::message::ut

#endif // UBSE_MANAGER_TEST_NODE_MEM_DEBTINFO_QUERY_REQ_SIMPO_H
