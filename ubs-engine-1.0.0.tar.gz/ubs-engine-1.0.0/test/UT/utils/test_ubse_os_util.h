/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef UBSE_MANAGER_TEST_UBSE_OS_UTIL_H
#define UBSE_MANAGER_TEST_UBSE_OS_UTIL_H

#include <grp.h>
#include <pwd.h>

#include "gtest/gtest.h"
#include "mockcpp/mockcpp.hpp"
#include "ubse_os_util.h"

namespace ubse::ut::utils {
class TestUbseOsUtil : public testing::Test {
public:
    TestUbseOsUtil() = default;
    void SetUp() override;
    void TearDown() override;

private:
    std::vector<std::pair<uid_t, std::string>> users = {{0, "root"}, {1, "bin"}};
};
} // namespace ubse::ut::utils

#endif // UBSE_MANAGER_TEST_UBSE_OS_UTIL_H
