/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */
#include "test_ubse_mem_common_utils.h"
#include "ubse_mem_common_utils.h"

namespace ubse::ut::mmi {
using namespace ubse::mmi;
TEST_F(TestUbseMemCommonUtils, GetFileFirstLine_Success)
{
    std::string path = "/proc/cmdline";
    std::string line;
    auto ret = RmCommonUtils::GetFileFirstLine(path, line);
    EXPECT_EQ(ret, UBSE_OK);
}

TEST_F(TestUbseMemCommonUtils, GetFileFirstLine_Fail)
{
    std::string path{};
    std::string line{};
    auto ret = RmCommonUtils::GetFileFirstLine(path, line);
    EXPECT_NE(ret, UBSE_OK);
}
}  // namespace ubse::ut::mmi
