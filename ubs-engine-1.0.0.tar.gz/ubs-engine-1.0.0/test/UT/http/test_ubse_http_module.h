/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef TEST_UBSE_HTTP_MODULE_H
#define TEST_UBSE_HTTP_MODULE_H

#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include "mockcpp/mockcpp.hpp"
#include "ubse_http_module.h"

namespace ubse::ut::http {

using namespace ubse::http;
using UbseHttpHandler =  uint32_t (*)(const UbseHttpRequest &req, UbseHttpResponse &resp);

class TestUbseHttpModule : public testing::Test {
public:
    TestUbseHttpModule();
    UbseHttpHandler tFunc;
    void SetUp() override;

    void TearDown() override;

protected:
    UbseHttpModule testRHM;
    UbseHttpRequest request;
    UbseHttpResponse response;
    UbseHttpHandlerFunc t_func;
};
}
#endif // TEST_UBSE_HTTP_MODULE_H
