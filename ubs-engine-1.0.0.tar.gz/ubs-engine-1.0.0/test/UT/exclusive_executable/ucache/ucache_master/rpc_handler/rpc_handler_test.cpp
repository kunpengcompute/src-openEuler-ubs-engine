/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

 * UBS uCache is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include <ubse_com.h>
#include <ubse_logger.h>
#include <gtest/gtest.h>
#include "mockcpp/mokc.h"
#define private public

#include "ucache_config.h"
#include "ucache_error.h"
#include "turbo_ucache_interface.h"
#include "master_task_controller.h"
#include "ucache_serialize.h"

using namespace ubse::log;
using namespace ubse::com;

namespace ucache::master {
using namespace ucache::serialize;

class RPCHandlerTest : public ::testing::Test {
protected:
    void SetUp() override {}

    void TearDown() override
    {
        GlobalMockObject::verify();
    }
};
}
