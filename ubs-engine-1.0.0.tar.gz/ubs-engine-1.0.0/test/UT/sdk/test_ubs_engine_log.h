/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
  *          http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef TEST_UBS_ENGINE_LOG_H
#define TEST_UBS_ENGINE_LOG_H

#include <gtest/gtest.h>

namespace ubse::sdk::ut {
class TestUbsEngineLog : public testing::Test {
public:
    TestUbsEngineLog() = default;

    void SetUp() override;

    void TearDown() override;

    class StdoutCapture {
    public:
        StdoutCapture()
        {
            testing::internal::CaptureStdout();
        }
        ~StdoutCapture()
        {
            if (!retrieved) {
                cached = testing::internal::GetCapturedStdout();
                retrieved = true;
            }
        }

        std::string output()
        {
            if (!retrieved) {
                retrieved = true;
                cached = testing::internal::GetCapturedStdout();
            }
            return cached;
        }

    private:
        bool retrieved = false;
        std::string cached;
    };
};
} // namespace ubse::sdk::ut

#endif // TEST_UBS_ENGINE_LOG_H
